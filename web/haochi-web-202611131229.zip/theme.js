/* 主题：配色、强调色、背景图案。选择存在 appearance9；第一次运行时沿用旧版 appearance4 里选过的主题。
   “搪瓷蓝”是默认，不写任何内联变量，深浅跟着手机走（app.css 里的 prefers-color-scheme）。 */
(function () {
  'use strict';
  var KEY = 'appearance9';
  var T = {
    enamel: { label: '搪瓷蓝', note: '跟随手机深浅', bg: '#F2F6F5', card: '#FFFFFF', accent: '#17408B' },
    orange: { label: '暖橙', bg: '#f7f8fa', card: '#ffffff', text: '#20272d', muted: '#737b83', line: '#e6e9ec', accent: '#c7472d' },
    green: { label: '森绿', bg: '#f5f8f7', card: '#ffffff', text: '#20322a', muted: '#6c7e73', line: '#dfe8e3', accent: '#27724f' },
    blue: { label: '海蓝', bg: '#f5f7fb', card: '#ffffff', text: '#222c3e', muted: '#6d7990', line: '#e0e6ef', accent: '#2459b1' },
    cream: { label: '奶油杏', bg: '#fff8ed', card: '#fffdf7', text: '#44372d', muted: '#7a6a5a', line: '#ebdfcc', accent: '#ad5936' },
    sakura: { label: '樱花粉', bg: '#fff5f7', card: '#fffcfd', text: '#48313c', muted: '#846470', line: '#eddce3', accent: '#a74668' },
    matcha: { label: '抹茶', bg: '#f5f5e9', card: '#fffff7', text: '#343f2e', muted: '#6d775d', line: '#e1e3cd', accent: '#596d3a' },
    frieren: { label: '芙莉莲', bg: '#f5f4fa', card: '#fffefa', text: '#353c50', muted: '#71768a', line: '#dedee9', accent: '#536d9c' },
    dark: { label: '夜色', dark: true, bg: '#14191f', card: '#20272f', text: '#edf2f6', muted: '#a1adb9', line: '#35404c', accent: '#f3a080' },
    cocoa: { label: '可可夜', dark: true, bg: '#27211e', card: '#352d27', text: '#f5ebdd', muted: '#c3b3a0', line: '#514438', accent: '#e3b887' }
  };
  var ACCENTS = ['#17408B', '#C7472D', '#27724F', '#7B4FB0', '#B8860B', '#C2456B', '#33706B', '#4A4A4A'];
  var WALLS = {
    plain: ['纯色', 'none', 'auto'],
    glow: ['柔光', 'radial-gradient(ellipse at 0% 12%,rgba(235,167,130,.38),transparent 50%),radial-gradient(ellipse at 100% 88%,rgba(141,175,193,.36),transparent 52%)', 'auto'],
    dots: ['点阵', 'radial-gradient(circle,rgba(95,115,130,.2) 1px,transparent 1.5px)', '18px 18px'],
    grid: ['细格', 'linear-gradient(rgba(95,115,130,.1) 1px,transparent 1px),linear-gradient(90deg,rgba(95,115,130,.1) 1px,transparent 1px)', '28px 28px']
  };
  var VARS = ['--bg', '--card', '--text', '--muted', '--line', '--accent', '--rim', '--rim-soft', '--tomato', '--on-accent', '--wall', '--wall-size'];
  var A = { theme: 'enamel', accent: '', wall: 'plain' };

  function read(k) { try { return JSON.parse(localStorage.getItem(k) || 'null'); } catch (e) { return null; } }
  (function load() {
    var s = read(KEY), old = read('appearance4');
    if (!s && old && T[old.theme] && old.theme !== 'orange') s = { theme: old.theme, accent: old.customAccent || '', wall: old.wall };
    if (s) { if (T[s.theme]) A.theme = s.theme; if (/^#[0-9a-f]{6}$/i.test(s.accent || '')) A.accent = s.accent; if (WALLS[s.wall]) A.wall = s.wall; }
  })();
  function save() { try { localStorage.setItem(KEY, JSON.stringify(A)); } catch (e) {} }

  function rgb(h) { return [1, 3, 5].map(function (i) { return parseInt(h.substr(i, 2), 16); }); }
  function hex(a) { return '#' + a.map(function (x) { return ('0' + Math.round(x).toString(16)).slice(-2); }).join(''); }
  function mix(a, b, t) { var x = rgb(a), y = rgb(b); return hex(x.map(function (v, i) { return v * t + y[i] * (1 - t); })); }
  function lum(h) {
    var c = rgb(h).map(function (v) { v /= 255; return v <= 0.04045 ? v / 12.92 : Math.pow((v + 0.055) / 1.055, 2.4); });
    return 0.2126 * c[0] + 0.7152 * c[1] + 0.0722 * c[2];
  }
  function onAccent(h) { return lum(h) > 0.179 ? '#14202d' : '#ffffff'; }
  function isDark() { var t = T[A.theme]; if (t && t.dark) return true; if (A.theme !== 'enamel') return false; try { return matchMedia('(prefers-color-scheme:dark)').matches; } catch (e) { return false; } }

  function apply() {
    var r = document.documentElement.style, t = T[A.theme];
    VARS.forEach(function (v) { r.removeProperty(v); });
    if (A.theme !== 'enamel') {
      r.setProperty('--bg', t.bg); r.setProperty('--card', t.card); r.setProperty('--text', t.text); r.setProperty('--muted', t.muted); r.setProperty('--line', t.line);
      r.setProperty('--accent', t.accent); r.setProperty('--rim', t.accent);
      r.setProperty('--rim-soft', mix(t.accent, t.dark ? t.card : t.bg, t.dark ? 0.28 : 0.14));
      r.setProperty('--tomato', t.dark ? '#ff7b6e' : '#cf2f26');
      r.setProperty('--on-accent', onAccent(t.accent));
    }
    if (A.accent) {
      var dark = isDark(), base = A.theme === 'enamel' ? (dark ? '#17234A' : '#F2F6F5') : (dark ? t.card : t.bg);
      r.setProperty('--accent', A.accent); r.setProperty('--rim', A.accent);
      r.setProperty('--rim-soft', mix(A.accent, base, dark ? 0.28 : 0.14));
      r.setProperty('--on-accent', onAccent(A.accent));
    }
    var w = WALLS[A.wall];
    if (A.wall !== 'plain') { r.setProperty('--wall', w[1]); r.setProperty('--wall-size', w[2]); }
    if (window.setAppearance) setAppearance();
  }
  window.themeDark = isDark;
  apply();
  try { matchMedia('(prefers-color-scheme:dark)').addEventListener('change', function () { if (A.theme === 'enamel') apply(); }); } catch (e) {}

  window.themeSettingsHTML = function () {
    var sw = Object.keys(T).map(function (k) {
      var t = T[k], on = A.theme === k;
      return '<button class="swatch ' + (on ? 'on' : '') + '" data-theme="' + k + '" aria-pressed="' + on + '" style="--sb:' + t.bg + ';--sc:' + t.card + ';--sa:' + t.accent + ';--st:' + (t.text || '#14203A') + '">' +
        '<i><u></u><u></u></i><b>' + t.label + '</b>' + (t.note ? '<small>' + t.note + '</small>' : '') + '</button>';
    }).join('');
    var dots = '<button class="dot none ' + (!A.accent ? 'on' : '') + '" data-accent="" aria-label="跟随主题">默认</button>' + ACCENTS.map(function (c) {
      return '<button class="dot ' + (A.accent.toLowerCase() === c.toLowerCase() ? 'on' : '') + '" data-accent="' + c + '" style="background:' + c + '" aria-label="强调色 ' + c + '"></button>';
    }).join('');
    var walls = Object.keys(WALLS).map(function (k) { return '<button class="chip ' + (A.wall === k ? 'on' : '') + '" data-wall="' + k + '">' + WALLS[k][0] + '</button>'; }).join('');
    return '<div class="set-group"><h3>主题</h3><div class="swatches">' + sw + '</div>' +
      '<h4 class="sub">强调色</h4><div class="dots">' + dots + '</div>' +
      '<h4 class="sub">背景图案</h4><div class="chips">' + walls + '</div></div>';
  };

  document.addEventListener('DOMContentLoaded', function () {
    $('pSet').addEventListener('click', function (e) {
      var el, changed = false;
      if ((el = e.target.closest('[data-theme]'))) { A.theme = el.getAttribute('data-theme'); changed = true; }
      else if ((el = e.target.closest('[data-accent]'))) { A.accent = el.getAttribute('data-accent'); changed = true; }
      else if ((el = e.target.closest('[data-wall]'))) { A.wall = el.getAttribute('data-wall'); changed = true; }
      if (!changed) return;
      save(); apply();
      var y = $('pSet').scrollTop; renderSettings(); $('pSet').scrollTop = y;
    });
  });
})();
