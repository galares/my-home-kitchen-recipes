/* 德国超市可买性判断 + 食材德语名（给「一周菜谱」和购物清单用）
   - ASIA_CORE：普通德国超市（REWE/Edeka/Aldi/Lidl/Kaufland）基本没有、要去亚洲店/网购的核心食材
   - ASIA_PANTRY：亚洲调味料，少量即可，通常一次买齐
   - 其余视为德国超市可买（含香菇、口蘑、金针菇、豆腐、生抽等常见国际货架商品） */
(function () {
  'use strict';
  var DE = {
    '鸡腿': 'Hähnchenschenkel', '去骨鸡腿': 'Hähnchenoberkeule, ausgelöst', '鸡腿肉': 'Hähnchenschenkel, ausgelöst',
    '鸡胸肉': 'Hähnchenbrust', '鸡肉': 'Hähnchenfleisch', '鸡翅': 'Hähnchenflügel', '鸡': 'Hähnchen',
    '鸡蛋': 'Eier', '蛋': 'Eier', '蛋黄': 'Eigelb', '蛋清': 'Eiweiß',
    '牛肉': 'Rindfleisch', '牛里脊': 'Rinderfilet', '牛腩': 'Rindergulasch', '牛腱': 'Rinderwade', '肥牛': 'Rindfleisch dünn geschnitten',
    '猪肉': 'Schweinefleisch', '五花肉': 'Schweinebauch', '猪里脊': 'Schweinefilet', '排骨': 'Schweinerippchen', '猪肋排': 'Schweinerippchen',
    '肉末': 'Hackfleisch', '肉丝': 'Fleischstreifen', '培根': 'Speck', '火腿': 'Schinken', '火腿肠': 'Wiener Würstchen', '香肠': 'Wurst',
    '虾仁': 'Garnelen, geschält', '虾': 'Garnelen', '虾滑': 'Garnelenpaste', '虾皮': 'getrocknete Garnelen',
    '鱼': 'Fisch', '三文鱼': 'Lachs', '鳕鱼': 'Kabeljau', '龙利鱼': 'Seezungenfilet', '鲈鱼': 'Wolfsbarsch', '带鱼': 'Haarbandfisch',
    '鱿鱼': 'Tintenfisch', '蛤蜊': 'Venusmuscheln', '花蛤': 'Venusmuscheln', '扇贝': 'Jakobsmuscheln',
    '豆腐': 'Tofu', '嫩豆腐': 'Seidentofu', '老豆腐': 'fester Tofu', '内酯豆腐': 'Seidentofu',
    '油豆腐': 'frittierter Tofu', '豆泡': 'frittierter Tofu', '腐竹': 'Tofu-Sticks', '千张': 'Tofu-Haut', '豆皮': 'Tofu-Haut',
    '牛奶': 'Milch', '黄油': 'Butter', '奶酪': 'Käse', '马苏里拉芝士': 'Mozzarella', '酸奶': 'Joghurt',
    '面粉': 'Mehl', '淀粉': 'Speisestärke', '玉米淀粉': 'Maisstärke', '生粉': 'Speisestärke', '面包糠': 'Semmelbrösel',
    '大米': 'Reis', '米饭': 'Reis', '熟米饭': 'gekochter Reis', '糯米': 'Klebreis', '小米': 'Hirse',
    '面条': 'Nudeln', '挂面': 'Nudeln', '乌冬': 'Udon-Nudeln', '乌冬面': 'Udon-Nudeln', '意面': 'Pasta',
    '粉丝': 'Glasnudeln', '米粉': 'Reisnudeln', '藜麦': 'Quinoa', '燕麦': 'Haferflocken', '年糕': 'Reiskuchen',
    '土豆': 'Kartoffeln', '红薯': 'Süßkartoffeln', '番茄': 'Tomaten', '西红柿': 'Tomaten',
    '洋葱': 'Zwiebeln', '胡萝卜': 'Karotten', '白萝卜': 'Rettich', '西兰花': 'Brokkoli', '花菜': 'Blumenkohl',
    '白菜': 'Chinakohl', '娃娃菜': 'Mini-Chinakohl', '包菜': 'Weißkohl', '生菜': 'Kopfsalat', '菠菜': 'Spinat',
    '油麦菜': 'Römersalat', '芹菜': 'Sellerie', '黄瓜': 'Gurke', '茄子': 'Aubergine', '西葫芦': 'Zucchini',
    '南瓜': 'Kürbis', '青椒': 'grüne Paprika', '彩椒': 'Paprika', '小米椒': 'Chilischoten', '辣椒': 'Chili',
    '苦瓜': 'Bittermelone', '丝瓜': 'Luffa', '莴笋': 'Stangensellerie', '空心菜': 'Wasserspinat', '菜心': 'Choy Sum',
    '韭菜': 'Schnittknoblauch', '豆芽': 'Sojasprossen', '四季豆': 'grüne Bohnen', '荷兰豆': 'Zuckerschoten',
    '豌豆': 'Erbsen', '毛豆': 'Edamame', '玉米': 'Mais', '芦笋': 'Spargel', '秋葵': 'Okra', '莲藕': 'Lotuswurzel',
    '山药': 'Yamswurzel', '芋头': 'Taro', '竹笋': 'Bambussprossen', '春笋': 'Bambussprossen',
    '姜': 'Ingwer', '蒜': 'Knoblauch', '大蒜': 'Knoblauch', '蒜头': 'Knoblauch', '蒜末': 'Knoblauch, gehackt',
    '葱': 'Frühlingszwiebeln', '小葱': 'Frühlingszwiebeln', '香葱': 'Frühlingszwiebeln', '大葱': 'Lauch', '葱花': 'Frühlingszwiebeln, gehackt',
    '香菜': 'Koriander', '蒜苗': 'Knoblauchhalme', '蒜薹': 'Knoblauchhalme',
    '蘑菇': 'Champignons', '口蘑': 'Champignons', '白蘑菇': 'Champignons', '香菇': 'Shiitake', '鲜香菇': 'frische Shiitake',
    '干香菇': 'getrocknete Shiitake', '平菇': 'Austernpilze', '杏鲍菇': 'Kräuterseitlinge', '金针菇': 'Enoki-Pilze',
    '白玉菇': 'weiße Buchenpilze', '蟹味菇': 'Buchenpilze', '海鲜菇': 'Kräuterseitlinge', '茶树菇': 'Teebaumpilze',
    '秀珍菇': 'Austernpilze', '舞茸': 'Maitake', '姬松茸': 'Agaricus-Pilze', '羊肚菌': 'Morcheln', '竹荪': 'Bambuspilz',
    '鸡油菌': 'Pfifferlinge', '虫草花': 'Cordyceps-Blüten', '银耳': 'weiße Mu-Err', '木耳': 'Mu-Err-Pilze', '黑木耳': 'Mu-Err-Pilze',
    '紫菜': 'Nori', '海带': 'Seetang', '裙带菜': 'Wakame',
    '红枣': 'Datteln', '枸杞': 'Goji-Beeren', '花生': 'Erdnüsse', '芝麻': 'Sesam', '白芝麻': 'Sesam',
    '柠檬': 'Zitrone', '青柠': 'Limette', '蜂蜜': 'Honig', '苹果': 'Apfel',
    '盐': 'Salz', '糖': 'Zucker', '白糖': 'Zucker', '冰糖': 'Kandiszucker', '红糖': 'brauner Zucker',
    '生抽': 'Sojasauce', '老抽': 'dunkle Sojasauce', '酱油': 'Sojasauce', '蚝油': 'Austernsauce', '醋': 'Essig',
    '料酒': 'Kochwein', '花雕酒': 'Shaoxing-Wein', '米酒': 'Reiswein', '香油': 'Sesamöl', '芝麻油': 'Sesamöl',
    '食用油': 'Öl', '油': 'Öl', '橄榄油': 'Olivenöl', '花生油': 'Erdnussöl', '菜籽油': 'Rapsöl',
    '咖喱块': 'Currypaste', '咖喱粉': 'Currypulver', '番茄酱': 'Tomatenmark', '豆瓣酱': 'Bohnenpaste (Doubanjiang)',
    '甜面酱': 'süße Bohnenpaste', '黄豆酱': 'Sojabohnenpaste', '辣椒酱': 'Chilisauce', '豆豉': 'fermentierte schwarze Bohnen',
    '花椒': 'Szechuanpfeffer', '八角': 'Sternanis', '桂皮': 'Zimtstange', '香叶': 'Lorbeerblätter',
    '孜然': 'Kreuzkümmel', '胡椒粉': 'Pfeffer', '黑胡椒': 'schwarzer Pfeffer', '白胡椒': 'weißer Pfeffer',
    '鸡精': 'Hühnerbrühe', '味精': 'Glutamat', '蒸鱼豉油': 'gedämpfte Sojasauce', '泡椒': 'eingelegte Chili',
    '泡姜': 'eingelegter Ingwer', '十三香': 'Fünf-Gewürze-Pulver', '五香粉': 'Fünf-Gewürze-Pulver',
    '淀粉水': 'Speisestärke-Wasser', '水淀粉': 'Speisestärke-Wasser'
  };

  var ASIA_CORE = [
    '鹿茸菇', '羊肚菌', '竹荪', '舞茸', '姬松茸', '鸡油菌', '虫草花', '茶树菇', '秀珍菇', '海鲜菇',
    '蟹味菇', '白玉菇', '银耳', '木耳', '黑木耳', '海带', '裙带菜', '虾皮', '腐竹', '千张', '豆皮',
    '油豆腐', '豆泡', '莲藕', '山药', '芋头', '竹笋', '春笋', '丝瓜', '空心菜', '菜心', '韭菜',
    '苦瓜', '莴笋', '豆芽', '米粉', '粉丝', '乌冬', '年糕', '紫菜', '酸菜', '泡菜'
  ];
  var ASIA_PANTRY = [
    '豆瓣酱', '甜面酱', '黄豆酱', '豆豉', '泡椒', '泡姜', '花雕酒', '料酒', '老抽', '蚝油',
    '香油', '芝麻油', '花椒', '八角', '桂皮', '十三香', '五香粉', '鸡精', '味精', '蒸鱼豉油',
    '辣椒酱', '干香菇', '干木耳', '腐乳', '海鲜酱', '叉烧酱', '沙茶酱', '辣椒面'
  ];

  function clean(name) {
    return String(name == null ? '' : name).split(/[（(·\/／]/)[0].trim();
  }
  function hit(name, list) {
    for (var i = 0; i < list.length; i++) if (name.indexOf(list[i]) >= 0) return list[i];
    return null;
  }
  function deName(name) {
    var n = clean(name);
    if (DE[n]) return DE[n];
    for (var k in DE) if (n.indexOf(k) >= 0) return DE[k];
    return '';
  }
  function info(r) {
    var core = [], pantry = [], german = 0, total = 0;
    (r && r.ingredients || []).forEach(function (it) {
      if (!Array.isArray(it) || !it[0]) return;
      var n = clean(it[0]);
      if (!n || /^(水|清水|热水|温水|开水|凉水)$/.test(n)) return;
      total++;
      if (hit(n, ASIA_CORE)) core.push(n);
      else if (hit(n, ASIA_PANTRY)) pantry.push(n);
      else german++;
    });
    var unique = function (a) { return a.filter(function (x, i) { return a.indexOf(x) === i; }); };
    core = unique(core); pantry = unique(pantry);
    var tier = core.length === 0 ? 'A' : (core.length === 1 ? 'B' : 'C');
    return { tier: tier, core: core, pantry: pantry, german: german, total: total };
  }
  window.DEShop = { de: DE, name: deName, info: info, core: ASIA_CORE, pantry: ASIA_PANTRY, clean: clean };
})();
