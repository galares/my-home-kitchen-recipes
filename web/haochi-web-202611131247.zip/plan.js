/* 一周菜谱 · 增肌/干净饮食（8.7）
   依赖 base.html / ui.js 的全局：R、E、icon、openR、goPage、shop、renderShop、localStorage。
   营养为按用料估算值（nutrition 字段），不是营养师数据。 */
(function () {
  'use strict';
  var KEY = 'weekPlan87';
  var DEF = { kcal: 2200, protein: 150, carb: 254, fat: 65, mealCount: 2, maxTime: 30, clean: true, deFirst: true };
  var PROTEIN_CATS = ['鸡肉', '牛肉', '猪肉', '鱼', '虾/海鲜', '鸡蛋', '豆腐', '鸭肉', '羊肉', '其他肉类'];
  var CL_KINDS = ['热菜', '凉菜', '汤羹', '主食', '面点'];
  var DAYS = ['周一', '周二', '周三', '周四', '周五', '周六', '周日'];
  var MEALS = { 2: ['午餐', '晚餐'], 3: ['午餐', '晚餐', '加餐'] };
  var mainEl = document.querySelector('main.wrap');
  var navin = document.querySelector('.nav .navin');
  if (!mainEl || !navin) return;
  var $ = function (id) { return document.getElementById(id); };
  var state = { settings: Object.assign({}, DEF), plan: null, seed: 87 };
  try {
    var raw = JSON.parse(localStorage.getItem(KEY) || 'null');
    if (raw && typeof raw === 'object') {
      state.settings = Object.assign({}, DEF, raw.settings || {});
      state.plan = raw.plan || null;
      state.seed = +raw.seed || 87;
    }
  } catch (e) {}
  var settings = Object.assign({}, DEF, state.settings);
  if (!MEALS[settings.mealCount]) settings.mealCount = 2;
  var plan = state.plan;

  function hasNut(r) {
    var n = r && r.nutrition;
    return !!(n && isFinite(n.kcal) && isFinite(n.protein) && isFinite(n.carb) && isFinite(n.fat));
  }
  function nk(r) { return hasNut(r) ? +r.nutrition.kcal : 0; }
  function np(r) { return hasNut(r) ? +r.nutrition.protein : 0; }
  function nc(r) { return hasNut(r) ? +r.nutrition.carb : 0; }
  function nf(r) { return hasNut(r) ? +r.nutrition.fat : 0; }
  function recipe(name) { return R.find(function (r) { return r.name === name; }); }
  function macroOf(name) { var r = recipe(name); return { kcal: nk(r), protein: np(r), carb: nc(r), fat: nf(r) }; }
  function round(n) { return Math.round(n * 10) / 10; }
  function fmtKcal(n) { return Math.round(n) + ' kcal'; }
  function fmtG(n) { return round(n) + 'g'; }

  function cleanOK(r) {
    if (!settings.clean) return true;
    if (['甜点', '饮品', '调料', '早餐', '其他'].indexOf(r.category) >= 0) return false;
    if (/炸|干煸|糖醋|拔丝|奶油|芝士|可乐/.test(r.name)) return false;
    if (nk(r) > 650) return false;
    if (nf(r) > 30) return false;
    return true;
  }
  function eligible(r) {
    if (!r || !r.sourceChecked || !hasNut(r)) return false;
    var t = +r.time || 30;
    if (t > settings.maxTime + 10) return false;
    return cleanOK(r);
  }
  function poolsFrom(all) {
    return {
      protein: all.filter(function (r) { return PROTEIN_CATS.indexOf(r.category) >= 0 && np(r) >= 20; }),
      veg: all.filter(function (r) { return r.category === '蔬菜' && nk(r) <= 260; }),
      staple: all.filter(function (r) { return r.category === '主食' && nc(r) >= 25; }),
      snack: all.filter(function (r) { return PROTEIN_CATS.indexOf(r.category) >= 0 && np(r) >= 15 && nk(r) <= 350; })
    };
  }
  function deTier(r) {
    try { return (window.DEShop && DEShop.info(r).tier) || 'A'; } catch (e) { return 'A'; }
  }
  function buildPools() {
    var all = R.filter(eligible);
    if (!settings.deFirst) return poolsFrom(all);
    var A = poolsFrom(all.filter(function (r) { return deTier(r) === 'A'; }));
    if (A.protein.length >= 18 && A.veg.length >= 10 && A.staple.length >= 8) return A;
    var AB = poolsFrom(all.filter(function (r) { return deTier(r) !== 'C'; }));
    if (AB.protein.length >= 14 && AB.veg.length >= 8) return AB;
    return poolsFrom(all);
  }
  function rng(seed) {
    var a = seed >>> 0;
    return function () {
      a |= 0; a = a + 0x6D2B79F5 | 0;
      var t = Math.imul(a ^ a >>> 15, 1 | a);
      t = t + Math.imul(t ^ t >>> 7, 61 | t) ^ t;
      return ((t ^ t >>> 14) >>> 0) / 4294967296;
    };
  }
  function pick(list, used, rnd) {
    if (!list.length) return null;
    var avail = list.filter(function (r) { return !used.has(r.name); });
    if (!avail.length) avail = list;
    var r = avail[Math.floor(rnd() * avail.length)];
    used.add(r.name);
    return r;
  }
  // 蛋白菜优先从蛋白量较高的候选里随机，避免一周蛋白长期偏低
  function pickProtein(list, used, rnd) {
    if (!list.length) return null;
    var avail = list.filter(function (r) { return !used.has(r.name); });
    if (!avail.length) avail = list;
    avail = avail.slice().sort(function (a, b) { return np(b) - np(a); });
    var top = avail.slice(0, Math.max(6, Math.ceil(avail.length * 0.5)));
    var r = top[Math.floor(rnd() * top.length)];
    used.add(r.name);
    return r;
  }
  function generate(seed) {
    var pools = buildPools();
    if (!pools.protein.length || !pools.staple.length) return null;
    var rnd = rng(seed);
    var used = new Set();
    var labels = MEALS[settings.mealCount] || MEALS[2];
    var shares = settings.mealCount === 2 ? [0.52, 0.48] : [0.42, 0.40, 0.18];
    var plannedShare = settings.mealCount === 2 ? 0.8 : 0.88;
    var days = [];
    for (var d = 0; d < 7; d++) {
      var meals = [];
      for (var m = 0; m < labels.length; m++) {
        var slots = [];
        if (labels[m] === '加餐') {
          var sn = pick(pools.snack, used, rnd) || pick(pools.protein, used, rnd);
          if (sn) slots.push({ kind: 'protein', name: sn.name });
        } else {
          var p = pickProtein(pools.protein, used, rnd);
          if (p) slots.push({ kind: 'protein', name: p.name });
          var v = pick(pools.veg, used, rnd);
          if (v) slots.push({ kind: 'veg', name: v.name });
          var target = settings.kcal * plannedShare * shares[m];
          var cur = slots.reduce(function (a, s) { return a + macroOf(s.name).kcal; }, 0);
          if (target - cur > 230) {
            var st = pick(pools.staple, used, rnd);
            if (st) slots.push({ kind: 'staple', name: st.name });
          }
        }
        meals.push({ label: labels[m], slots: slots });
      }
      days.push({ day: DAYS[d], meals: meals });
    }
    return { days: days, seed: seed };
  }

  function save() {
    try { localStorage.setItem(KEY, JSON.stringify({ settings: settings, plan: plan, seed: state.seed })); } catch (e) {}
  }
  function dayTotals(day) {
    var t = { kcal: 0, protein: 0, carb: 0, fat: 0 };
    day.meals.forEach(function (meal) {
      meal.slots.forEach(function (s) {
        var m = macroOf(s.name);
        t.kcal += m.kcal; t.protein += m.protein; t.carb += m.carb; t.fat += m.fat;
      });
    });
    return t;
  }
  function mealTotals(meal) {
    var t = { kcal: 0, protein: 0, carb: 0, fat: 0 };
    meal.slots.forEach(function (s) {
      var m = macroOf(s.name);
      t.kcal += m.kcal; t.protein += m.protein; t.carb += m.carb; t.fat += m.fat;
    });
    return t;
  }

  function pageHTML() {
    return '' +
      '<div class="page-heading"><h1>一周吃什么</h1><p>按增肌、干净饮食搭配：每餐蛋白质＋蔬菜＋主食，先看搭配再买菜。</p></div>' +
      '<details class="panel week-panel"><summary>目标和筛选</summary>' +
      '<div class="week-settings-grid">' +
      '<label>每日热量目标（kcal）<input id="wkKcal" type="number" min="1200" max="4500" step="50" inputmode="numeric" value="' + settings.kcal + '"></label>' +
      '<label>每日蛋白质（g）<input id="wkProtein" type="number" min="60" max="300" step="5" inputmode="numeric" value="' + settings.protein + '"></label>' +
      '<label>每日碳水（g）<input id="wkCarb" type="number" min="80" max="500" step="5" inputmode="numeric" value="' + settings.carb + '"></label>' +
      '<label>每日脂肪（g）<input id="wkFat" type="number" min="30" max="150" step="5" inputmode="numeric" value="' + settings.fat + '"></label>' +
      '<label>每天餐数<select id="wkMeals"><option value="2"' + (settings.mealCount === 2 ? ' selected' : '') + '>午餐＋晚餐</option><option value="3"' + (settings.mealCount === 3 ? ' selected' : '') + '>午餐＋晚餐＋加餐</option></select></label>' +
      '<label>每餐可用时间<select id="wkTime"><option value="20"' + (settings.maxTime === 20 ? ' selected' : '') + '>20 分钟以内</option><option value="30"' + (settings.maxTime === 30 ? ' selected' : '') + '>约 30 分钟</option><option value="45"' + (settings.maxTime === 45 ? ' selected' : '') + '>45 分钟以上</option></select></label>' +
      '<label class="week-check"><input id="wkClean" type="checkbox"' + (settings.clean ? ' checked' : '') + '> 只看干净菜（少油炸/高糖）</label>' +
      '<label class="week-check"><input id="wkDe" type="checkbox"' + (settings.deFirst ? ' checked' : '') + '> 优先德国超市能买到的菜（亚洲店另列）</label>' +
      '</div>' +
      '<div class="week-actions"><button class="primary" id="wkGen">重新生成一周</button><button id="wkReset">恢复默认目标</button></div>' +
      '<p class="week-note">营养是按用料估算的参考值，不是营养师或医学建议；“加餐”只排一道高蛋白菜。目标可随体重和训练量调整。</p>' +
      '</details>' +
      '<div class="panel week-panel" id="wkCl"></div>' +
      '<div class="week-summary" id="wkSummary"></div>' +
      '<p class="week-note" id="wkGap"></p>' +
      '<p class="week-note" id="wkDeNote"></p>' +
      '<div class="week-days" id="weekDays"></div>' +
      '<div class="panel week-cart"><h3>一周买菜</h3><p class="small">把这一周的用料合并成一张清单（含调料），同名食材会尽量相加。</p><button class="primary" id="wkShop">一键把一周用料加入购物清单</button><p class="small" id="wkStatus" role="status"></p></div>';
  }

  function renderSummary() {
    var el = $('wkSummary');
    if (!el) return;
    if (!plan) { el.innerHTML = ''; return; }
    if (plan.cl) { el.innerHTML = ''; if ($('wkGap')) $('wkGap').textContent = '这一周是用村驴的菜排的，按家里食材、用时和难度挑，没有营养估算。'; if ($('wkDeNote')) $('wkDeNote').textContent = ''; return; }
    var tot = { kcal: 0, protein: 0, carb: 0, fat: 0 };
    plan.days.forEach(function (d) { var t = dayTotals(d); tot.kcal += t.kcal; tot.protein += t.protein; tot.carb += t.carb; tot.fat += t.fat; });
    var n = plan.days.length || 1;
    var cov = settings.kcal * (settings.mealCount === 2 ? 0.8 : 0.88);
    el.innerHTML = [
      ['日均热量', fmtKcal(tot.kcal / n), '两餐覆盖约 ' + Math.round((tot.kcal / n) / (cov || 1) * 100) + '%'],
      ['日均蛋白', fmtG(tot.protein / n), '目标 ' + settings.protein + 'g/天'],
      ['日均碳水', fmtG(tot.carb / n), '目标 ' + settings.carb + 'g/天'],
      ['日均脂肪', fmtG(tot.fat / n), '目标 ' + settings.fat + 'g/天']
    ].map(function (x) {
      return '<div class="week-stat"><b>' + x[1] + '</b><span>' + x[0] + ' · ' + x[2] + '</span></div>';
    }).join('');
    var gap = $('wkGap');
    if (gap) {
      var gapP = settings.protein - tot.protein / n;
      var gapK = settings.kcal - tot.kcal / n;
      gap.textContent = gapP > 5
        ? '两餐已提供蛋白 ' + fmtG(tot.protein / n) + '，早餐/加餐还需约 ' + fmtG(gapP) + '（热量约 ' + fmtKcal(gapK) + '）。可把「每天餐数」改成三餐，或早餐加鸡蛋/牛奶/希腊酸奶。'
        : '两餐已接近每日目标；若训练量大，可在训练后补一份高蛋白加餐。';
      if (gapP > 5) {
        var snacks = buildPools().snack.slice().sort(function (a, b) { return np(b) / Math.max(1, nk(b)) - np(a) / Math.max(1, nk(a)); }).slice(0, 3);
        if (snacks.length) gap.textContent += ' 加餐候选：' + snacks.map(function (r) { return r.name + '（' + round(np(r)) + 'g 蛋白）'; }).join('、') + '。';
      }
    }
    var deNote = $('wkDeNote');
    if (deNote) {
      if (!settings.deFirst) {
        deNote.textContent = '德国超市筛选已关闭：会排到需要亚洲店的菜。';
      } else {
        var asia = {};
        var bDishes = 0;
        plan.days.forEach(function (d) {
          d.meals.forEach(function (m) {
            m.slots.forEach(function (sl) {
              var r = recipe(sl.name); if (!r) return;
              var info = (window.DEShop && DEShop.info(r)) || { tier: 'A', core: [], pantry: [] };
              if (info.tier !== 'A' || info.pantry.length) bDishes++;
              info.core.concat(info.pantry).forEach(function (x) { asia[x] = 1; });
            });
          });
        });
        var list = Object.keys(asia);
        deNote.textContent = list.length
          ? '本周有 ' + bDishes + ' 道用到亚洲店食材（普通德国超市不一定有）：' + list.join('、') + '。这些会在购物清单里单独分组；买不到时可用同栏“换”换成普通超市菜。'
          : '本周菜谱都能在普通德国超市（REWE/Edeka/Aldi/Lidl/Kaufland）买齐。';
      }
    }
  }

  function kindLabel(k) { return k === 'cl' ? '村驴' : k === 'protein' ? '蛋白' : k === 'veg' ? '蔬菜' : k === 'staple' ? '主食' : '菜'; }

  function renderDays() {
    var box = $('weekDays');
    if (!box) return;
    if (!plan) {
      box.innerHTML = '<div class="week-empty">还没有生成计划。点上面的「重新生成一周」即可排好 7 天。若提示菜品不足，说明当前营养数据或时间筛选过严。</div>';
      return;
    }
    box.innerHTML = plan.days.map(function (day, di) {
      var t = dayTotals(day);
      var cov = settings.kcal * (settings.mealCount === 2 ? 0.8 : 0.88);
      var pct = Math.max(4, Math.min(100, Math.round(t.kcal / (cov || 1) * 100)));
      var meals = day.meals.map(function (meal, mi) {
        var mt = mealTotals(meal);
        var rows = meal.slots.map(function (s, si) {
          var m = macroOf(s.name);
          var r = recipe(s.name);
          var di2 = (window.DEShop && r) ? DEShop.info(r) : null;
          var deBadge = !di2 ? '' : di2.tier === 'A' ? '<span class="week-de ok">🇩🇪 德国超市</span>'
            : di2.tier === 'B' ? '<span class="week-de asia">亚洲店×1</span>'
            : '<span class="week-de asia">亚洲店×' + (di2.core.length + (di2.core.length ? 0 : 1)) + '</span>';
          return '<div class="week-slot">' +
            '<button class="week-open" data-open="' + encodeURIComponent(s.name) + '" aria-label="查看 ' + E(s.name) + '"><span>' + E(s.name) + '</span><span class="week-tags"><span class="week-kind">' + kindLabel(s.kind) + '</span>' + deBadge + '</span></button>' +
            '<span class="week-macro">' + (hasNut(r) ? Math.round(m.kcal) + ' kcal · P' + round(m.protein) : (typeof clMeta === 'function' && clMeta(s.name)) || '无营养数据') + '</span>' +
            '<button class="week-swap" data-di="' + di + '" data-mi="' + mi + '" data-si="' + si + '" aria-label="换一道 ' + E(s.name) + '">换</button>' +
            '</div>';
        }).join('');
        return '<div class="week-meal"><div class="week-meal-head"><b>' + meal.label + '</b>' + (plan.cl ? '' : '<span>' + Math.round(mt.kcal) + ' kcal · 蛋白 ' + round(mt.protein) + 'g</span>') + '</div>' + rows + '</div>';
      }).join('');
      return '<article class="week-day"><div class="week-day-head"><h3>' + day.day + '</h3>' + (plan.cl ? '' : '<span class="small">' + Math.round(t.kcal) + ' kcal · 蛋白 ' + round(t.protein) + 'g</span>') + '</div>' + (plan.cl ? '' : '<div class="week-bar"><i style="width:' + pct + '%"></i></div>') + '<div class="week-meals">' + meals + '</div></article>';
    }).join('');
  }

  function renderAll() { renderSummary(); renderDays(); }

  /* ---------- 村驴排一周 ---------- */
  function clPanelHTML() {
    var chips = function (key, arr) {
      return arr.map(function (x) { return '<button class="chip ' + ((settings[key] || 0) === x[0] ? 'on' : '') + '" data-wkcl="' + key + '" data-v="' + x[0] + '">' + x[1] + '</button>'; }).join('');
    };
    return '<h3>用村驴的菜排一周</h3><p class="small">按家里记的食材、快吃掉的优先挑，不重样。选了难度和用时，就只在范围内挑。</p>' +
      '<div class="chips">' + chips('clLv', [[0, '难度不限'], [1, '只要简单'], [2, '最多中等']]) + '</div>' +
      '<div class="chips">' + chips('clTm', [[0, '用时不限'], [30, '30分钟内'], [60, '1小时内']]) + '</div>' +
      '<div class="week-actions"><button class="primary" id="wkClGen">用村驴的菜排一周</button></div>';
  }
  function mainOf(n) { return ((typeof TAGS !== 'undefined' && TAGS[n]) || '').split('|')[0].split(',')[0]; }
  function clPickDish(used, prevMain, rank) { // 按匹配度、快吃的、随机挑一道；used 里的不再挑
    var best = null, bs = -1;
    Object.keys(CUNLV).forEach(function (n) {
      if (used.has(n)) return;
      var r = CUNLV[n][0];
      if (CL_KINDS.indexOf(r.cat) < 0) return;
      if (settings.clLv && r.lv > settings.clLv) return;
      if (settings.clTm && r.min > settings.clTm) return;
      var m = rank && rank[n];
      var sc = (m ? m.pct + m.soon * 15 + m.nw * 5 + (m.can ? 20 : 0) : rank ? 0 : 40) + Math.random() * 30;
      if (prevMain && mainOf(n) === prevMain) sc -= 25; // 连着两餐别总是同一种主料
      if (r.cat === '热菜' || r.cat === '主食' || r.cat === '面点') sc += 6;
      if (sc > bs) { bs = sc; best = n; }
    });
    return best;
  }
  function generateCl() {
    if (typeof CUNLV === 'undefined') return null;
    var rank = window.pantryRank ? pantryRank() : null, used = new Set(), prev = '', days = [];
    var labels = (MEALS[settings.mealCount] || MEALS[2]).filter(function (l) { return l !== '加餐'; });
    for (var d = 0; d < 7; d++) {
      var meals = [];
      labels.forEach(function (lab) {
        var n = clPickDish(used, prev, rank), slots = [];
        if (n) { used.add(n); slots.push({ kind: 'cl', name: n }); prev = mainOf(n); }
        meals.push({ label: lab, slots: slots });
      });
      days.push({ day: DAYS[d], meals: meals });
    }
    return { days: days, seed: state.seed, cl: true };
  }
  function regenerate(seed) {
    state.seed = seed || (Date.now() % 1000000007);
    plan = generate(state.seed);
    if (!plan) {
      var pools = buildPools();
      if ($('wkStatus')) $('wkStatus').textContent = '可用菜品不足（蛋白 ' + pools.protein.length + ' 道、蔬菜 ' + pools.veg.length + ' 道、主食 ' + pools.staple.length + ' 道）。请放宽时间或营养数据尚未生成。';
    } else if ($('wkStatus')) {
      $('wkStatus').textContent = '';
    }
    save();
    renderAll();
  }

  function swap(di, mi, si) {
    if (!plan) return;
    var slot = plan.days[di].meals[mi].slots[si];
    if (!slot) return;
    if (slot.kind === 'cl') {
      var used0 = new Set();
      plan.days.forEach(function (d) { d.meals.forEach(function (m) { m.slots.forEach(function (s) { used0.add(s.name); }); }); });
      var nn = clPickDish(used0, '', window.pantryRank ? pantryRank() : null);
      if (nn) { slot.name = nn; save(); renderAll(); } else if ($('wkStatus')) $('wkStatus').textContent = '没有更多符合条件的村驴菜了，放宽一下难度或用时。';
      return;
    }
    var pools = buildPools();
    var list = slot.kind === 'veg' ? pools.veg : slot.kind === 'staple' ? pools.staple : (plan.days[di].meals[mi].label === '加餐' ? pools.snack : pools.protein);
    var usedNames = new Set();
    plan.days.forEach(function (d) { d.meals.forEach(function (m) { m.slots.forEach(function (s) { usedNames.add(s.name); }); }); });
    var avail = list.filter(function (r) { return r.name !== slot.name && !usedNames.has(r.name); });
    if (!avail.length) avail = list.filter(function (r) { return r.name !== slot.name; });
    if (!avail.length) return;
    slot.name = avail[Math.floor(Math.random() * avail.length)].name;
    save();
    renderAll();
  }

  function parseAmt(s) {
    var m = String(s).trim().match(/^([\d.]+)\s*(kg|千克|g|克|ml|毫升|个|只|根|瓣|片|勺|汤匙|汤勺|茶匙|碗|杯|把)$/i);
    if (!m) return null;
    var n = parseFloat(m[1]);
    var u = m[2];
    if (/kg|千克/i.test(u)) { n *= 1000; u = 'g'; }
    if (/毫升/i.test(u)) u = 'ml';
    if (/克/i.test(u)) u = 'g';
    if (/汤匙|汤勺|勺/.test(u)) u = '勺';
    if (!isFinite(n) || n <= 0) return null;
    return { num: n, unit: u };
  }
  function combineAmt(a, b) {
    var pa = parseAmt(a), pb = parseAmt(b);
    if (pa && pb && pa.unit === pb.unit) {
      var n = pa.num + pb.num;
      return (Math.round(n * 10) / 10) + pa.unit;
    }
    return a + ' + ' + b;
  }
  function itemLabel(nm) {
    var de = (window.DEShop && DEShop.name(nm)) || '';
    return de ? (nm + '（' + de + '）') : nm;
  }
  function isAsiaItem(nm) {
    if (!window.DEShop) return false;
    var n = DEShop.clean(nm);
    for (var i = 0; i < DEShop.core.length; i++) if (n.indexOf(DEShop.core[i]) >= 0) return true;
    for (var j = 0; j < DEShop.pantry.length; j++) if (n.indexOf(DEShop.pantry[j]) >= 0) return true;
    return false;
  }
  function aggregate() {
    var g = new Map(), a = new Map();
    plan.days.forEach(function (day) {
      day.meals.forEach(function (meal) {
        meal.slots.forEach(function (s) {
          var r = recipe(s.name);
          if (!r || !Array.isArray(r.ingredients)) return;
          r.ingredients.forEach(function (it) {
            if (!Array.isArray(it) || !it[0]) return;
            var nm = String(it[0]).trim();
            var amt = String(it[1] || '').trim();
            if (!nm) return;
            var map = isAsiaItem(nm) ? a : g;
            map.set(nm, map.has(nm) ? combineAmt(map.get(nm), amt) : amt);
          });
        });
      });
    });
    var clGroups = [];
    plan.days.forEach(function (day) { day.meals.forEach(function (meal) { meal.slots.forEach(function (s) {
      var cr = typeof CUNLV !== 'undefined' && CUNLV[s.name];
      if (cr && !recipe(s.name)) clGroups.push({ name: s.name, mult: 1, items: cr[0].ing.map(function (i) { return [i[0], i[1] || '']; }) });
    }); }); });
    var toItems = function (m) { return Array.from(m.entries()).map(function (e) { return [itemLabel(e[0]), e[1]]; }); };
    return { german: toItems(g), asia: toItems(a), cl: clGroups };
  }
  function addToShop() {
    if (!plan) return;
    var items = aggregate();
    if (!items.german.length && !items.asia.length && !items.cl.length) { $('wkStatus').textContent = '计划里没有可汇总的用料。'; return; }
    if (items.german.length) shop.push({ name: '一周计划 · 德国超市', mult: 1, items: items.german });
    if (items.asia.length) shop.push({ name: '一周计划 · 亚洲店/网购', mult: 1, items: items.asia });
    items.cl.forEach(function (g) { shop.push(g); });
    try { localStorage.setItem('shop2', JSON.stringify(shop)); } catch (e) {}
    if (typeof renderShop === 'function') renderShop();
    var other = items.german.length || items.asia.length;
    $('wkStatus').textContent = '已加入买菜清单：' + (other ? '德国超市 ' + items.german.length + ' 项，亚洲店 ' + items.asia.length + ' 项' : '') + (items.cl.length ? (other ? '；' : '') + '村驴的菜 ' + items.cl.length + ' 道（清单里选“合并”看总数）' : '') + '。';
  }

  function applySettingsFromForm() {
    var kcal = parseInt(($('wkKcal') || {}).value, 10);
    var protein = parseInt(($('wkProtein') || {}).value, 10);
    var carb = parseInt(($('wkCarb') || {}).value, 10);
    var fat = parseInt(($('wkFat') || {}).value, 10);
    var meals = parseInt(($('wkMeals') || {}).value, 10);
    var time = parseInt(($('wkTime') || {}).value, 10);
    if (kcal >= 1200 && kcal <= 4500) settings.kcal = kcal;
    if (protein >= 60 && protein <= 300) settings.protein = protein;
    if (carb >= 80 && carb <= 500) settings.carb = carb;
    if (fat >= 30 && fat <= 150) settings.fat = fat;
    if (MEALS[meals]) settings.mealCount = meals;
    if ([20, 30, 45].indexOf(time) >= 0) settings.maxTime = time;
    settings.clean = !!($('wkClean') || {}).checked;
    settings.deFirst = !!($('wkDe') || {}).checked;
    save();
    renderAll();
  }

  window.weekAddDish = function (di, mi, name) {
    if (!plan) regenerate(state.seed);
    if (!plan) return false;
    var day = plan.days[di]; var meal = day && day.meals[mi];
    if (!meal) return false;
    meal.slots.push({ kind: 'other', name: name });
    save(); renderAll();
    return true;
  };

  function wire() {
    mainEl.insertAdjacentHTML('beforeend', '<section id="pWeek" class="page">' + pageHTML() + '</section>');
    navin.insertAdjacentHTML('beforeend', '<button data-p="Week">' + icon('sun') + '<span class="nav-label">一周<span class="nav-note">本周吃什么</span></span></button>');
    var navBtn = navin.querySelector('[data-p="Week"]');
    if (navBtn) navBtn.onclick = function () { if (typeof goPage === 'function') goPage('Week'); renderAll(); };
    ['wkKcal', 'wkProtein', 'wkCarb', 'wkFat', 'wkMeals', 'wkTime', 'wkClean', 'wkDe'].forEach(function (id) {
      var el = $(id);
      if (el) el.addEventListener('change', applySettingsFromForm);
    });
    $('wkGen').onclick = function () { applySettingsFromForm(); regenerate(); };
    $('wkReset').onclick = function () {
      settings = Object.assign({}, DEF);
      if (plan) { plan = generate(state.seed = 87); }
      save();
      $('wkKcal').value = settings.kcal; $('wkProtein').value = settings.protein;
      $('wkCarb').value = settings.carb; $('wkFat').value = settings.fat;
      $('wkMeals').value = settings.mealCount; $('wkTime').value = settings.maxTime;
      $('wkClean').checked = settings.clean;
      $('wkDe').checked = settings.deFirst;
      renderAll();
    };
    var clBox = $('wkCl');
    if (clBox) {
      clBox.innerHTML = clPanelHTML();
      clBox.addEventListener('click', function (e) {
        var c = e.target.closest('[data-wkcl]');
        if (c) { settings[c.getAttribute('data-wkcl')] = +c.getAttribute('data-v'); save(); clBox.innerHTML = clPanelHTML(); return; }
        if (e.target.closest('#wkClGen')) {
          var p = generateCl();
          if (!p) { $('wkStatus').textContent = '村驴的菜还没加载。'; return; }
          var empty = p.days.some(function (d) { return d.meals.some(function (m) { return !m.slots.length; }); });
          plan = p; save(); renderAll();
          $('wkStatus').textContent = empty ? '符合条件的村驴菜不够排满一周，放宽难度或用时会更满。' : '已用村驴的菜排好一周，不满意可以点每道菜旁的“换”。';
          if (typeof toast === 'function') toast('已排好一周');
        }
      });
    }
    $('wkShop').onclick = addToShop;
    $('weekDays').addEventListener('click', function (e) {
      var open = e.target.closest('[data-open]');
      if (open) { if (typeof openR === 'function') openR(decodeURIComponent(open.getAttribute('data-open'))); return; }
      var sw = e.target.closest('[data-si]');
      if (sw) swap(+sw.getAttribute('data-di'), +sw.getAttribute('data-mi'), +sw.getAttribute('data-si'));
    });
    // 菜谱详情页追加「营养估算」一行
    if (typeof openR === 'function') {
      var prevOpen = openR;
      openR = function (name) {
        prevOpen(name);
        var r = recipe(name);
        if (!r || !hasNut(r)) return;
        var n = r.nutrition;
        var sheet = document.getElementById('sheet');
        if (!sheet) return;
        sheet.insertAdjacentHTML('beforeend',
          '<div class="section week-nutrition"><h4>营养估算（1 人份）</h4>' +
          '<p class="small">' + Math.round(n.kcal) + ' kcal · 蛋白 ' + round(n.protein) + 'g · 碳水 ' + round(n.carb) + 'g · 脂肪 ' + round(n.fat) + 'g</p>' +
          '<p class="small">按用料估算，仅供参考，不是营养师数据。' + E(n.note || '') + '</p></div>');
      };
    }
    var withNut = R.filter(hasNut).length;
    if (!withNut) {
      $('weekDays').innerHTML = '<div class="week-empty">营养数据还没有生成，暂时不能排一周计划。先运行 work/nutrition/estimate.py 并合并 nutrition-map.json。</div>';
      $('wkGen').disabled = true;
      $('wkShop').disabled = true;
      return;
    }
    if (!plan) regenerate(state.seed);
    else renderAll();
  }

  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', wire);
  else wire();
})();
