/* 食材：记下家里有什么、刚买了什么，按食材推荐能做的菜。
   依赖 data.js 的 VOCAB / TAGS / STAPLE_DEFAULT，和 app.js 的 LS、E、$、ALL、R、shop、toast、goPage、ACTS。
   每道菜的主料（决定这道菜是什么）和配料（次要或特色调料）都用食材表里的规范名；
   匹配度 = 已有的主料(权重 1) + 已有的配料(权重 0.4) 占全部的比例。基础调料（盐、油、糖…）默认一直有，不计入。 */
(function () {
  'use strict';
  var KEY = 'pantry9';
  var ST = { new: '刚买', have: '家里有', soon: '快吃掉' };
  var COMMON = ['鸡蛋', '番茄', '土豆', '洋葱', '鸡肉', '猪肉', '牛肉', '鱼', '虾', '豆腐', '大白菜', '青菜', '胡萝卜', '青椒', '黄瓜', '茄子', '香菇', '西兰花', '米饭', '面条', '牛奶', '葱', '姜', '蒜'];

  /* 食材表里没有的食材怎么办（2026-11-02 定的规则）：
     1 认得：整句相等 > 最长别名包含 → 规范名；
     2 不认得：不丢、不乱归类。用户输入、清单里买回来、改食材时写到的新词，一律登记成“我加的食材”（XV，存 vocabx9），
       之后它和正式食材一样：能在“按类别挑”里点、能被识别、能进备份；
     3 名字里带这个词的菜自动算用到它（见 tagsOf），旧版菜谱用料里认不得的词保留成配料，而不是悄悄丢掉。 */
  var XV = LS.get('vocabx9', []);
  var CATOF = {}, ALIAS = {}, SINGLE = {}, LIST = [], NC = {}, STAPLE_ALL = {}, built = false;
  function buildVocab() {
    if (built) return; built = true;
    CATOF = {}; ALIAS = {}; SINGLE = {}; STAPLE_ALL = {};
    VOCAB.forEach(function (c) {
      c[1].forEach(function (it) {
        CATOF[it[0]] = c[0];
        if (c[0] === '基础调料') STAPLE_ALL[it[0]] = 1;
        it.forEach(function (a) { if (a.length === 1) SINGLE[a] = it[0]; else ALIAS[a] = it[0]; });
      });
    });
    XV.forEach(function (n) { CATOF[n] = '我加的'; if (n.length === 1) SINGLE[n] = SINGLE[n] || n; else ALIAS[n] = ALIAS[n] || n; });
    LIST = Object.keys(ALIAS).sort(function (a, b) { return b.length - a.length; });
  }
  function resetCaches() { built = false; NC = {}; DT = {}; cache = null; buildVocab(); }
  /* 登记一个新食材；已经认得、太短太长、不是中文词的不登记。返回是否新登记 */
  function registerXV(n) {
    n = String(n || '').replace(/[（(][^）)]*[）)]/g, '').replace(/\s+/g, '').trim();
    if (!/^[一-龥]{2,8}$/.test(n)) return false;
    buildVocab(); if (ALIAS[n] || SINGLE[n] || norm(n) === n) return false;
    XV.push(n); LS.set('vocabx9', XV); resetCaches(); return true;
  }
  var NOT_ING = /^(清|热|温|开|凉|冰|纯净)?水$|^适量|^少许|^若干/;
  /* 把任意写法归到规范名：整句相等 > 单字整句相等 > 最长别名包含；找不到返回空串 */
  function norm(s) {
    buildVocab();
    s = String(s == null ? '' : s).replace(/[（(][^）)]*[）)]/g, '').replace(/\s+/g, '').trim();
    if (!s) return '';
    if (NC[s] !== undefined) return NC[s];
    var r = ALIAS[s] || SINGLE[s] || '';
    if (!r) for (var i = 0; i < LIST.length; i++) if (s.indexOf(LIST[i]) >= 0) { r = ALIAS[LIST[i]]; break; }
    return (NC[s] = r);
  }

  var P = LS.get(KEY, null) || {};
  P.items = P.items || {};
  P.staples = P.staples || STAPLE_DEFAULT.slice();
  P.addAs = P.addAs || 'new';
  P.view = P.view || 'have';
  function save() { LS.set(KEY, P); }
  var FIX = LS.get('tagfix9', {}); // 用户自己改过的菜的食材：{菜名:{main:[],side:[]}}
  function names() { return Object.keys(P.items); }

  /* ---------- 菜的食材标签 ---------- */
  var DT = {};
  function parseTag(s) { var a = s.split('|'); return { main: a[0] ? a[0].split(',') : [], side: a[1] ? a[1].split(',') : [] }; }
  function tagsOf(name) {
    if (DT[name] !== undefined) return DT[name];
    var t = null, r = byR[name];
    if (FIX[name]) t = { main: FIX[name].main.slice(), side: FIX[name].side.slice() };
    else if (typeof TAGS !== 'undefined' && TAGS[name]) t = parseTag(TAGS[name]);
    else if (r && r.ingredients) {
      var out = [], raw = [];
      r.ingredients.forEach(function (i) {
        var c = norm(i[0]);
        if (c) { if (!STAPLE_ALL[c] && out.indexOf(c) < 0) out.push(c); return; }
        var w = String(i[0] || '').replace(/[（(][^）)]*[）)]/g, '').trim(); // 食材表里没有的词保留成配料，不悄悄丢掉
        if (/^[一-龥]{2,8}$/.test(w) && !NOT_ING.test(w) && raw.indexOf(w) < 0) raw.push(w);
      });
      if (out.length) t = { main: out.slice(0, 3), side: out.slice(3, 8).concat(raw.slice(0, 3)) };
    } else if (byName[name] && byName[name].mine) {
      // 只有用户自己加的菜才按菜名猜；词库里没标签的菜不参与匹配，免得误报“齐了”
      var c = norm(name); if (c && !STAPLE_ALL[c]) t = { main: [c], side: [] };
    }
    if (XV.length && !FIX[name]) { // 名字里带“我加的食材”的菜，自动算用到它
      var hit = XV.filter(function (w) { return name.indexOf(w) >= 0; });
      if (hit.length) { t = t || { main: [], side: [] }; hit.forEach(function (w) { if (t.main.indexOf(w) < 0) t.main.unshift(w); }); t.main = t.main.slice(0, 4); }
    }
    return (DT[name] = t);
  }
  function have(n) { return P.items[n] || (P.staples.indexOf(n) >= 0 ? { st: 'staple' } : null); }
  /* 菜页的用料行用：这个原始写法在家里有没有。'' 不认得或没记食材（不标），'staple' 基础调料，'have' 有，'miss' 缺 */
  var EXTRA = {"通脊肉": "猪肉", "大里脊": "猪肉", "里脊": "猪肉", "猪前蹄": "猪蹄", "花甲": "蛤蜊", "大骨头": "猪骨", "牛棒骨": "牛骨", "小鸡": "鸡肉", "鸡架": "鸡肉", "护心肉": "猪肉", "肥肉": "猪肉", "猪皮": "猪肉", "鸭子": "鸭肉", "鸭头": "鸭肉", "牛腿肉": "牛肉", "鲜虾": "虾", "活虾": "虾", "猪前肘": "猪肘", "羊骨头": "羊肉", "鸡骨头": "鸡肉", "鸡骨架或鸡叉骨": "鸡肉", "小公鸡或肉食鸡": "鸡肉", "大骨": "猪骨", "新鲜脊骨块": "猪骨", "猪尾巴": "猪肉", "羊血": "羊肉", "中等粗细的葱": "葱", "小毛葱": "葱", "干姜": "姜", "苏子叶": "紫苏", "牛肋排": "牛肉", "薄骨": "排骨", "熟水发牛板筋": "牛肉", "牛板筋": "牛肉"}; // 和 build.py 的 EXTRA_ALIAS 保持一致
  window.pantryHas = function (raw) {
    if (!names().length) return '';
    var c = norm(EXTRA[String(raw).replace(/[（(][^）)]*[）)]/g, '').trim()] || raw); if (!c) return '';
    if (P.staples.indexOf(c) >= 0 || STAPLE_ALL[c]) return 'staple';
    return P.items[c] ? 'have' : 'miss';
  };
  window.pantryRank = function () { // 菜名 → 匹配结果（家里食材）；没记食材时返回 null
    if (!names().length) return null;
    if (!cache) cache = compute();
    var o = {}; cache.forEach(function (m) { o[m.d.name] = m; }); return o;
  };
  window.pantryCanon = function (raw) { // 清单合并用：任意写法 → 规范名，认不得就用去掉括号的原名
    var r = String(raw || '').replace(/[（(][^）)]*[）)]/g, '').trim();
    return norm(EXTRA[r] || r) || r;
  };
  window.pantryCat = function (c) { buildVocab(); return CATOF[c] || ''; };
  function matchDish(dt) {
    var tot = 0, got = 0, missM = [], missS = [], used = [], soon = 0, nw = 0;
    dt.main.forEach(function (n) { tot += 1; var o = have(n); if (o) { got += 1; used.push(n); } else missM.push(n); });
    dt.side.forEach(function (n) { tot += 0.4; var o = have(n); if (o) { got += 0.4; used.push(n); } else missS.push(n); });
    used.forEach(function (n) { var o = P.items[n]; if (o && o.st === 'soon') soon++; if (o && o.st === 'new') nw++; });
    return { pct: Math.round(100 * got / tot), missM: missM, missS: missS, used: used, soon: soon, nw: nw, ownedMain: dt.main.length - missM.length };
  }
  function compute() {
    var out = [];
    ALL.forEach(function (d) {
      var dt = tagsOf(d.name); if (!dt || !dt.main.length) return;
      var m = matchDish(dt); if (!m.ownedMain || m.pct < 50) return;
      m.d = d; m.can = !m.missM.length; m.near = m.missM.length >= 1 && m.missM.length <= 2; out.push(m);
    });
    return out;
  }
  function hasCl(n) { return typeof CUNLV !== 'undefined' && CUNLV[n] ? 1 : 0; }
  var onlyCl = false, newF = false, lvF = 0, tmF = 0; // 难度 0 不限 1 简单 2 中等 3 费工；时间 0 不限，否则最多多少分钟
  function clR(n) { return typeof CUNLV !== 'undefined' && CUNLV[n] ? CUNLV[n][0] : null; }
  var SORTS = {
    easy: function (a, b) { var x = clR(a.d.name), y = clR(b.d.name); return (x ? x.lv : 9) - (y ? y.lv : 9) || b.pct - a.pct || (x ? x.min : 999) - (y ? y.min : 999); },
    fast: function (a, b) { var x = clR(a.d.name), y = clR(b.d.name); return (x ? x.min : 9999) - (y ? y.min : 9999) || b.pct - a.pct; },
    pct: function (a, b) { return b.pct - a.pct || b.soon - a.soon || b.nw - a.nw || hasCl(b.d.name) - hasCl(a.d.name) || (b.d.r ? 1 : 0) - (a.d.r ? 1 : 0) || a.d.name.length - b.d.name.length; },
    soon: function (a, b) { return b.soon - a.soon || b.pct - a.pct || b.nw - a.nw || a.d.name.length - b.d.name.length; },
    nw: function (a, b) { return b.nw - a.nw || b.pct - a.pct || b.soon - a.soon || a.d.name.length - b.d.name.length; }
  };

  /* ---------- 页面 ---------- */
  var filt = 'all', sortBy = 'pct', cache = null, ownOpen = false, sweet = false;
  var SWEET = { 7: 1, 8: 1, 9: 1, 12: 1 }; // 甜品 烘焙 饮品 腌酱：默认不进“能做什么”
  function root() { return $('pPantry'); }
  function ageText(it) {
    if (it.st !== 'new') return ST[it.st];
    var d = Math.floor((Date.now() - (it.at || Date.now())) / 864e5);
    return d <= 0 ? '今天买的' : d + ' 天前买的';
  }
  function stale(it) { return it.st === 'new' && (Date.now() - (it.at || Date.now())) / 864e5 >= 4; }

  window.renderPantry = function () {
    var n = names().length, el = root();
    if (!n) P.view = 'have';
    el.innerHTML = '<h1 class="page-title">食材</h1>' +
      '<div class="seg"><button data-pv="have" class="' + (P.view === 'have' ? 'on' : '') + '">我的食材 ' + n + '</button><button data-pv="cook" class="' + (P.view === 'cook' ? 'on' : '') + '">能做什么</button></div>' +
      '<div id="pBody"></div>';
    if (P.view === 'cook') renderCook(); else renderHave();
  };

  function renderHave() {
    var cats = '';
    VOCAB.forEach(function (c) {
      if (c[0] === '基础调料') return;
      cats += '<details class="pcat"><summary>' + E(c[0]) + '</summary><div class="chips">' + c[1].map(function (it) { return chip(it[0]); }).join('') + '</div></details>';
    });
    if (XV.length) {
      cats += '<details class="pcat"><summary>我加的 ' + XV.length + ' 样</summary><p class="small">食材表里没有、你自己加的。名字里带它的菜会参与匹配；点“×”可以从食材表里删掉。</p><div class="chips">' +
        XV.map(function (n) { return '<span class="xv">' + chip(n) + '<button class="xvdel" data-xvdel="' + E(n) + '" aria-label="删除 ' + E(n) + '">×</button></span>'; }).join('') + '</div></details>';
    }
    $('pBody').innerHTML =
      '<div class="pant-add"><input id="pIn" placeholder="加一样食材，比如 鸡蛋" enterkeyhint="done" autocomplete="off"><button class="btn primary" data-padd-input>加入</button></div>' +
      '<div class="chips" id="pSug"></div>' +
      '<div class="addas">加入为<div class="st-seg">' + ['new', 'have'].map(function (k) { return '<button data-pas="' + k + '" class="' + (P.addAs === k ? 'on' : '') + '">' + ST[k] + '的</button>'; }).join('') + '</div></div>' +
      '<div id="pOwnBox" hidden><h2 class="block-title">已有的 <small id="pCnt"></small></h2><ul class="own-list" id="pOwn"></ul><button class="more" id="pOwnMore" hidden></button></div>' +
      '<h2 class="block-title">常用</h2><div class="chips">' + COMMON.map(chip).join('') + '</div>' +
      '<h2 class="block-title">按类别挑</h2>' + cats +
      '<details class="pcat staples"><summary>默认一直有的调料 ' + P.staples.length + ' 样</summary><p class="small">这些算家里有，不计入匹配度。点一下可以取消或加回。</p><div class="chips">' +
      Object.keys(STAPLE_ALL).map(function (n) { return '<button class="chip ' + (P.staples.indexOf(n) >= 0 ? 'on' : '') + '" data-pstaple="' + E(n) + '">' + E(n) + '</button>'; }).join('') + '</div></details>';
    renderOwn();
  }
  function chip(n) { return '<button class="chip ' + (P.items[n] ? 'on' : '') + '" data-padd="' + E(n) + '">' + E(n) + '</button>'; }
  function renderOwn() {
    var order = { soon: 0, new: 1, have: 2 }, list = names().sort(function (a, b) { return order[P.items[a].st] - order[P.items[b].st] || (P.items[b].at || 0) - (P.items[a].at || 0); });
    var ul = $('pOwn'); if (!ul) return;
    $('pOwnBox').hidden = !list.length;
    $('pCnt').textContent = list.length ? list.length + ' 样' : '';
    var LIMIT = 6, more = $('pOwnMore'), total = list.length;
    if (total > LIMIT && !ownOpen) list = list.slice(0, LIMIT);
    more.hidden = total <= LIMIT; more.textContent = ownOpen ? '收起' : '展开剩下 ' + (total - LIMIT) + ' 样';
    ul.innerHTML = list.length ? list.map(function (n) {
      var it = P.items[n];
      return '<li class="own-row"><div class="own-name"><b>' + E(n) + '</b><small class="' + (stale(it) ? 'warn' : '') + '">' + E(ageText(it)) + (stale(it) ? '，别放太久' : '') + '</small></div>' +
        '<div class="st-seg">' + ['new', 'have', 'soon'].map(function (k) { return '<button data-pst="' + k + '" data-n="' + E(n) + '" class="' + (it.st === k ? 'on ' + k : '') + '">' + ST[k] + '</button>'; }).join('') + '</div>' +
        '<button class="link-del" data-prm="' + E(n) + '" aria-label="移除 ' + E(n) + '">×</button></li>';
    }).join('') : '';
    var seg = document.querySelector('[data-pv="have"]'); if (seg) seg.textContent = '我的食材 ' + total;
  }
  function syncChips(n) {
    document.querySelectorAll('[data-padd="' + (window.CSS && CSS.escape ? CSS.escape(n) : n) + '"]').forEach(function (b) { b.classList.toggle('on', !!P.items[n]); });
  }
  function add(n, st) {
    n = String(n || '').trim(); if (!n) return false;
    if (!P.items[n]) P.items[n] = { st: st || P.addAs, at: Date.now() };
    save(); cache = null; return true;
  }
  function removeItem(n) { delete P.items[n]; save(); cache = null; }
  function typed() {
    var q = ($('pIn').value || '').trim(), box = $('pSug'); if (!box) return;
    if (!q) { box.innerHTML = ''; return; }
    var out = [];
    VOCAB.forEach(function (c) { if (c[0] === '基础调料') return; c[1].forEach(function (it) { if (out.length < 10 && (it[0].indexOf(q) >= 0 || it.some(function (a) { return a.indexOf(q) >= 0; }))) out.push(it[0]); }); });
    box.innerHTML = out.map(chip).join('') || '<span class="small">食材表里没有“' + E(q) + '”。按回车或点“加入”，会记成你自己的食材，名字里带它的菜也会参与匹配。</span>';
  }
  function addTyped() {
    var inp = $('pIn'), q = inp.value.trim(); if (!q) return;
    var c = norm(q), fresh = false;
    if (c && STAPLE_ALL[c]) { toast('“' + c + '”是基础调料，默认一直有'); return; }
    var name = c;
    if (!c) {
      if (!registerXV(q)) { toast('请输入 2 到 8 个字的食材名'); return; }
      name = q.replace(/[（(][^）)]*[）)]/g, '').replace(/\s+/g, ''); fresh = true;
    }
    add(name); inp.value = ''; typed();
    if (fresh) renderHave(); else { renderOwn(); syncChips(name); }
    toast(fresh ? '食材表里没有“' + name + '”，已记成你自己的食材（' + ST[P.items[name].st] + '）' : '已加入：' + name + '（' + ST[P.items[name].st] + '）');
  }

  function renderCook() {
    var body = $('pBody');
    if (!names().length) { body.innerHTML = '<div class="empty"><b>先记下家里有什么</b>在“我的食材”里点几样，这里就会按匹配度列出能做的菜。<br><button class="btn primary" data-pv="have" style="margin-top:14px">去记食材</button></div>'; return; }
    if (!cache) {
      // 首次要给九千多道菜算一遍，先让界面画出来再算
      body.innerHTML = '<p class="small" style="padding:28px 4px">正在按你的食材算…</p>';
      setTimeout(function () { if (P.view !== 'cook' || !root().querySelector('#pBody')) return; cache = compute(); renderCook(); }, 30);
      return;
    }
    var clN = cache.filter(function (m) { return hasCl(m.d.name) && (sweet || !SWEET[m.d.t]); }).length;
    var all = sweet ? cache : cache.filter(function (m) { return !SWEET[m.d.t]; });
    if (newF) all = all.filter(function (m) { return !madeN(m.d.name); });
    if (onlyCl || lvF || tmF) all = all.filter(function (m) { var r = clR(m.d.name); return r && (!lvF || r.lv === lvF) && (!tmF || r.min <= tmF); });
    var can = all.filter(function (m) { return m.can; }), near = all.filter(function (m) { return m.near; });
    var list = (filt === 'can' ? can : filt === 'near' ? near : all).slice().sort(SORTS[sortBy]);
    body.innerHTML =
      '<div class="chips">' + [['all', '全部 ' + all.length], ['can', '现在能做 ' + can.length], ['near', '差一两样 ' + near.length]].map(function (f) { return '<button class="chip ' + (filt === f[0] ? 'on' : '') + '" data-pf="' + f[0] + '">' + f[1] + '</button>'; }).join('') +
      '<button class="chip ' + (sweet ? 'on' : '') + '" data-psw aria-pressed="' + sweet + '">含甜品饮品</button>' +
      (typeof CUNLV !== 'undefined' ? '<button class="chip ' + (onlyCl ? 'on' : '') + '" data-pcl aria-pressed="' + onlyCl + '">只看村驴有做法的 ' + clN + '</button>' : '') +
      '<button class="chip ' + (newF ? 'on' : '') + '" data-pnew aria-pressed="' + newF + '">没做过的</button></div>' +
      (typeof CUNLV !== 'undefined' ? '<div class="sortbar">村驴菜<div class="st-seg">' + [[1, '简单'], [2, '中等'], [3, '费工']].map(function (s) { return '<button data-plv="' + s[0] + '" class="' + (lvF === s[0] ? 'on' : '') + '">' + s[1] + '</button>'; }).join('') + '</div><div class="st-seg">' + [[30, '≤30分'], [60, '≤1小时']].map(function (s) { return '<button data-ptm="' + s[0] + '" class="' + (tmF === s[0] ? 'on' : '') + '">' + s[1] + '</button>'; }).join('') + '</div></div>' : '') +
      '<div class="sortbar">排序<div class="st-seg">' + [['pct', '匹配度'], ['soon', '先用快吃的'], ['nw', '先用刚买的'], ['easy', '最简单'], ['fast', '最快']].map(function (s) { return '<button data-ps="' + s[0] + '" class="' + (sortBy === s[0] ? 'on' : '') + '">' + s[1] + '</button>'; }).join('') + '</div></div>' +
      (list.length ? '<ul class="dish-list" id="pRes"></ul><button class="more" id="pMore" hidden>再看 60 道</button>' : '<div class="empty"><b>暂时没有匹配的菜</b>多记几样食材，或者把“差一两样”打开看看缺什么。</div>');
    if (list.length) paint(list);
  }
  function rowHTML(m) {
    var used = m.used.map(function (n) { var it = P.items[n]; return E(n) + (it && it.st !== 'have' ? '·' + ST[it.st] : ''); }).join('、');
    var miss = m.missM.concat(m.missS.map(function (n) { return n; }));
    return '<li><button class="dish-row match" data-open="' + E(m.d.name) + '"><span class="m-main"><b>' + E(m.d.name) + '</b>' + (hasCl(m.d.name) ? '<span class="cl-tag">村驴做法 · ' + clMeta(m.d.name) + '</span>' : '') +
      '<span class="m-sub">用到 ' + used + '</span>' +
      (miss.length ? '<span class="m-miss">差 ' + miss.map(E).join('、') + '</span>' : '<span class="m-ok">食材都有</span>') + '</span>' +
      '<span class="pct ' + (m.can ? 'full' : '') + '">' + (m.pct >= 100 ? '齐了' : m.pct + '%') + '</span></button></li>';
  }
  function paint(list) {
    var ul = $('pRes'), more = $('pMore'), n = 0;
    ul.innerHTML = '';
    function step() { ul.insertAdjacentHTML('beforeend', list.slice(n, n + 60).map(rowHTML).join('')); n += 60; more.hidden = n >= list.length; }
    more.onclick = step; step();
  }

  /* ---------- 菜名页里的“食材够吗” ---------- */
  var lastMiss = [];
  window.pantrySheetHTML = function (name) {
    var dt = tagsOf(name), fixBtn = '<button class="btn" data-act="fixTags">' + (dt && dt.main.length ? '改食材' : '设置食材') + '</button>';
    if (!dt || !dt.main.length) return '<div class="section-head"><h3>食材够吗</h3></div><p class="small">这道菜还没有食材信息，设置后就能按你的食材推荐。</p><div class="btn-row">' + fixBtn + '</div>';
    if (!names().length) return '<div class="section-head"><h3>食材够吗</h3></div><p class="small">先在“食材”页记下家里有什么，这里就能告诉你够不够。</p><div class="btn-row">' + fixBtn + '</div>';
    var m = matchDish(dt);
    function line(n, side) {
      var it = P.items[n], ok = !!have(n);
      return '<li class="' + (ok ? 'ok' : 'no') + '"><span>' + (ok ? '有' : '缺') + '　' + E(n) + (side ? '（配料）' : '') + '</span><span>' + (it ? E(ST[it.st]) : '') + '</span></li>';
    }
    lastMiss = m.missM.concat(m.missS);
    return '<div class="section-head"><h3>食材够吗</h3><small>' + (m.pct >= 100 ? '齐了' : '匹配 ' + m.pct + '%') + '</small></div><ul class="ing need">' +
      dt.main.map(function (n) { return line(n, false); }).join('') + dt.side.map(function (n) { return line(n, true); }).join('') + '</ul>' +
      '<div class="btn-row">' + (lastMiss.length ? '<button class="btn" data-act="needAdd">缺的 ' + lastMiss.length + ' 样加入清单</button>' : '') + fixBtn + '</div>';
  };
  /* 标签是模型按菜名标的，难免有错：让用户自己改，改过的优先 */
  function parseList(s) {
    var out = [], bad = [];
    var fresh = [];
    String(s).split(/[、,，;；\s]+/).forEach(function (x) {
      if (!x) return;
      var c = norm(x);
      if (!c) { if (/^[一-龥]{2,8}$/.test(x)) { fresh.push(x); c = x; } else { bad.push(x); return; } } // 表里没有的中文词：保存时登记成“我加的食材”
      if (STAPLE_ALL[c]) return; if (out.indexOf(c) < 0) out.push(c);
    });
    return { out: out, bad: bad, fresh: fresh };
  }
  ACTS.fixTags = function () {
    var dt = tagsOf(curDish) || { main: [], side: [] };
    $('modalBody').innerHTML = '<h3>这道菜用到什么</h3><p class="small">用顿号或空格隔开。主料决定这道菜是什么，配料是次要的；盐、油、酱油这类基础调料不用写。食材表里没有的会记成你自己的食材。</p>' +
      '<label class="field">主料<input id="fxMain" value="' + E(dt.main.join('、')) + '" placeholder="比如 鸡蛋、番茄"></label>' +
      '<label class="field">配料<input id="fxSide" value="' + E(dt.side.join('、')) + '" placeholder="比如 葱、蒜"></label><p class="small" id="fxErr" style="color:var(--tomato)"></p>' +
      '<div class="btn-row"><button class="btn" data-act="modalClose">取消</button>' + (FIX[curDish] ? '<button class="btn" data-act="fxReset">恢复原样</button>' : '') + '<button class="btn primary" data-act="fxSave">保存</button></div>';
    showModal();
  };
  ACTS.fxSave = function () {
    var m = parseList($('fxMain').value), s = parseList($('fxSide').value), err = $('fxErr');
    if (!m.out.length) { err.textContent = '主料至少要有一样。'; return; }
    if (m.bad.length || s.bad.length) { err.textContent = '“' + m.bad.concat(s.bad).join('、') + '”不像食材名，请写 2 到 8 个汉字。'; return; }
    m.fresh.concat(s.fresh).forEach(registerXV);
    FIX[curDish] = { main: m.out.slice(0, 6), side: s.out.filter(function (x) { return m.out.indexOf(x) < 0; }).slice(0, 6) };
    LS.set('tagfix9', FIX); delete DT[curDish]; cache = null; closeModal(); renderSheet(); toast('已保存这道菜的食材');
  };
  ACTS.fxReset = function () { delete FIX[curDish]; LS.set('tagfix9', FIX); delete DT[curDish]; cache = null; closeModal(); renderSheet(); toast('已恢复原来的食材'); };
  ACTS.needAdd = function () {
    if (!lastMiss.length) return;
    shop.push({ name: curDish + '（缺的）', mult: 1, items: lastMiss.map(function (n) { return [n, '']; }) });
    saveShop(); toast('已把缺的 ' + lastMiss.length + ' 样加入清单');
  };
  /* 清单里勾选的 = 买回来了，放进食材（刚买），并从清单里拿掉 */
  ACTS.shopToPantry = function () {
    var moved = 0, keep = [];
    shop.forEach(function (g, gi) {
      var rest = [];
      (g.items || []).forEach(function (it) {
        var key = gi + '|' + g.name + '|' + it[0];
        if (!shopDone.has(key)) { rest.push(it); return; }
        var c = norm(it[0]);
        if (c && STAPLE_ALL[c]) return;
        var raw = String(it[0]).replace(/[（(][^）)]*[）)]/g, '').trim();
        if (!c) registerXV(raw); // 清单里买回来的、食材表里没有的：登记成我加的食材
        if (add(c || raw, 'new')) moved++;
      });
      if (rest.length) { g.items = rest; keep.push(g); }
    });
    shop = keep; shopDone = new Set(); saveShop(); renderShop();
    toast(moved ? '已把 ' + moved + ' 样放进食材（刚买）' : '勾选的都是基础调料，没有新增');
  };

  /* ---------- 首页入口卡（只数一数，不做匹配计算，免得首页变慢） ---------- */
  window.homePantryCard = function () {
    var ns = names();
    if (!ns.length) return '<button class="home-card" data-act="goPantryHave"><b>按家里的食材找菜</b><span>记下有什么、刚买了什么，按匹配度推荐能做的菜</span></button>';
    var soon = ns.filter(function (n) { return P.items[n].st === 'soon'; }), nw = ns.filter(function (n) { return P.items[n].st === 'new'; });
    var bits = ['家里有 ' + ns.length + ' 样'];
    if (nw.length) bits.push('刚买 ' + nw.length + ' 样');
    return '<button class="home-card on" data-act="goPantryCook"><b>' + E(bits.join('，')) + '</b>' +
      '<span>' + (soon.length ? '快吃掉：' + E(soon.slice(0, 3).join('、')) + (soon.length > 3 ? ' 等' : '') + '，点这里看看能做什么' : '点这里看看能做什么') + '</span></button>';
  };
  ACTS.goPantryHave = function () { P.view = 'have'; save(); goPage('Pantry'); };
  ACTS.goPantryCook = function () { P.view = 'cook'; save(); goPage('Pantry'); };

  /* ---------- 事件 ---------- */
  function onClick(e) {
    var t = e.target, el;
    if ((el = t.closest('[data-pv]'))) { P.view = el.getAttribute('data-pv'); save(); window.renderPantry(); return; }
    if ((el = t.closest('[data-padd]'))) {
      var n = el.getAttribute('data-padd');
      if (P.items[n]) removeItem(n); else add(n);
      syncChips(n); renderOwn(); return;
    }
    if (t.closest('[data-padd-input]')) { addTyped(); return; }
    if ((el = t.closest('[data-pas]'))) { P.addAs = el.getAttribute('data-pas'); save(); el.parentNode.querySelectorAll('button').forEach(function (b) { b.classList.toggle('on', b === el); }); return; }
    if ((el = t.closest('[data-pst]'))) { var k = el.getAttribute('data-pst'), nn = el.getAttribute('data-n'); if (P.items[nn]) { P.items[nn].st = k; if (k === 'new') P.items[nn].at = Date.now(); save(); cache = null; renderOwn(); } return; }
    if ((el = t.closest('[data-prm]'))) { var rn = el.getAttribute('data-prm'); removeItem(rn); renderOwn(); syncChips(rn); return; }
    if ((el = t.closest('[data-pstaple]'))) { var sn = el.getAttribute('data-pstaple'), i = P.staples.indexOf(sn); if (i >= 0) P.staples.splice(i, 1); else P.staples.push(sn); save(); cache = null; el.classList.toggle('on', i < 0); var s = document.querySelector('.staples summary'); if (s) s.textContent = '默认一直有的调料 ' + P.staples.length + ' 样'; return; }
    if ((el = t.closest('[data-xvdel]'))) {
      var xn = el.getAttribute('data-xvdel'); XV = XV.filter(function (x) { return x !== xn; }); LS.set('vocabx9', XV); delete P.items[xn]; save(); resetCaches(); renderHave();
      toast('已从食材表删掉“' + xn + '”'); return;
    }
    if (t.closest('#pOwnMore')) { ownOpen = !ownOpen; renderOwn(); return; }
    if ((el = t.closest('[data-plv]'))) { var v = +el.getAttribute('data-plv'); lvF = lvF === v ? 0 : v; renderCook(); return; }
    if ((el = t.closest('[data-ptm]'))) { var v2 = +el.getAttribute('data-ptm'); tmF = tmF === v2 ? 0 : v2; renderCook(); return; }
    if (t.closest('[data-pnew]')) { newF = !newF; renderCook(); return; }
    if (t.closest('[data-pcl]')) { onlyCl = !onlyCl; renderCook(); return; }
    if (t.closest('[data-psw]')) { sweet = !sweet; renderCook(); return; }
    if ((el = t.closest('[data-pf]'))) { filt = el.getAttribute('data-pf'); renderCook(); return; }
    if ((el = t.closest('[data-ps]'))) { sortBy = el.getAttribute('data-ps'); renderCook(); return; }
  }
  document.addEventListener('DOMContentLoaded', function () {
    var r = root();
    r.addEventListener('click', onClick);
    r.addEventListener('input', function (e) { if (e.target.id === 'pIn') typed(); });
    r.addEventListener('keydown', function (e) { if (e.target.id === 'pIn' && e.key === 'Enter') { e.preventDefault(); addTyped(); } });
  });
})();
