/* 做饭模式：份量换算、步骤计时器、一步一屏（村驴的做法用）。依赖 app.js 的 CL、clPick、clDone、E、$、toast、ACTS、renderSheet */
(function () {
  'use strict';
  var CN = { '一': 1, '二': 2, '两': 2, '三': 3, '四': 4, '五': 5, '六': 6, '七': 7, '八': 8, '九': 9, '十': 10 };
  function cnNum(s) { // 3、一、两、十、十五、二十 → 数
    if (/^\d+(\.\d+)?$/.test(s)) return parseFloat(s);
    if (s === '半') return 0.5;
    var m = s.match(/^([一二两三四五六七八九])?十([一二三四五六七八九])?$/);
    if (m) return (m[1] ? CN[m[1]] : 1) * 10 + (m[2] ? CN[m[2]] : 0);
    return s.length === 1 && CN[s] ? CN[s] : NaN;
  }
  /* ---------- 份量 ---------- */
  window.clK = 1;
  function fmt(v) {
    var n = Math.floor(v + 1e-9), f = v - n, g = '';
    if (v >= 100) return String(Math.round(v / 5) * 5);
    if (v >= 20) return String(Math.round(v));
    if (f < 0.06) return String(n);
    if (f > 0.94) return String(n + 1);
    if (Math.abs(f - 0.5) < 0.06) return n ? n + '.5' : '半';
    if (Math.abs(f - 0.25) < 0.04) g = '¼'; else if (Math.abs(f - 0.75) < 0.04) g = '¾';
    else if (Math.abs(f - 1 / 3) < 0.04) g = '⅓'; else if (Math.abs(f - 2 / 3) < 0.04) g = '⅔';
    if (g) return (n ? n : '') + g;
    return v.toFixed(1).replace(/\.0$/, '');
  }
  window.clFmt = fmt;
  window.clParseAmt = function (amt) { // '400克' → {v:400, unit:'克'}；'适量'、'薄薄两片' 返回 null
    amt = String(amt || '').replace(/[（(][^）)]*[）)]/g, '').trim();
    var m = amt.match(/^(?:约|大约|满满)?(\d+(?:\.\d+)?|[一二三四五六七八九]分之[一二三四五六七八九]|[一二两三四五六七八九十]{1,2}|半)(.*)$/);
    if (!m) return null;
    var q = m[1], rest = m[2].trim(), fr = q.match(/^([一二三四五六七八九])分之([一二三四五六七八九])$/);
    var v = fr ? CN[fr[2]] / CN[fr[1]] : cnNum(q);
    if (isNaN(v)) return null;
    if (/^(勺|茶勺|茶匙|个|斤|碗|杯|根|把)半/.test(rest)) { v += 0.5; rest = rest.replace('半', ''); }
    if (!rest || rest.length > 3) return null; // 没单位或“一点点好吃的”这类不算数
    return { v: v, unit: rest.replace(/^茶勺$/, '茶匙') };
  };
  window.clScale = function (amt, k) {
    amt = String(amt || '');
    if (!amt || k === 1) return amt;
    var m = amt.match(/^(约|大约|满满)?(\d+(?:\.\d+)?|[一二三四五六七八九]分之[一二三四五六七八九]|[一二两三四五六七八九十]{1,2}|半)(.*)$/);
    if (!m) return amt;
    var v, q = m[2], rest = m[3], fr = q.match(/^([一二三四五六七八九])分之([一二三四五六七八九])$/);
    v = fr ? CN[fr[2]] / CN[fr[1]] : cnNum(q);
    if (isNaN(v)) return amt;
    if (/^(勺|茶勺|茶匙|个|斤|碗|杯|根|把)半/.test(rest)) { v += 0.5; rest = rest.replace('半', ''); } // 一勺半
    return (m[1] || '') + fmt(v * k) + rest;
  };
  window.clKBar = function () {
    return '<div class="clk"><span>份量</span><div class="st-seg">' + [[0.5, '½'], [1, '×1'], [1.5, '×1.5'], [2, '×2'], [3, '×3']].map(function (x) {
      return '<button data-act="clK" data-k="' + x[0] + '" class="' + (window.clK === x[0] ? 'on' : '') + '">' + x[1] + '</button>';
    }).join('') + '</div></div>';
  };
  /* ---------- 计时 ---------- */
  window.clTimes = function (step) { // 找步骤里的时间 → [{label, sec}]
    var out = [], re = /(\d+(?:\.\d+)?|[一二两三四五六七八九十]{1,3}|半)\s*(?:[-~到至]\s*(?:\d+|[一二两三四五六七八九十]{1,3}))?\s*(个半小时|分钟|分|小时|个小时|秒钟|秒)/g, m;
    while ((m = re.exec(step))) {
      var v = cnNum(m[1]), u = m[2];
      if (isNaN(v)) continue;
      var sec = /小时/.test(u) ? v * 3600 + (/半/.test(u) ? 1800 : 0) : /^秒/.test(u) ? v : v * 60;
      if (sec < 10 || sec > 6 * 3600) continue;
      sec = Math.round(sec);
      var lab = sec >= 3600 ? (Math.round(sec / 360) / 10) + '小时' : sec >= 60 ? Math.round(sec / 60) + '分钟' : sec + '秒';
      if (!out.some(function (o) { return o.sec === sec; })) out.push({ label: lab, sec: sec });
    }
    return out;
  };
  var timers = [], tick = null, ac = null, tid = 0;
  function beep() {
    try {
      ac = ac || new (window.AudioContext || window.webkitAudioContext)();
      [0, 0.35, 0.7].forEach(function (d) {
        var o = ac.createOscillator(), g = ac.createGain();
        o.frequency.value = 880; o.connect(g); g.connect(ac.destination);
        g.gain.setValueAtTime(0.0001, ac.currentTime + d);
        g.gain.exponentialRampToValueAtTime(0.4, ac.currentTime + d + 0.02);
        g.gain.exponentialRampToValueAtTime(0.0001, ac.currentTime + d + 0.25);
        o.start(ac.currentTime + d); o.stop(ac.currentTime + d + 0.3);
      });
    } catch (e) { }
    try { if (navigator.vibrate) navigator.vibrate([300, 150, 300]); } catch (e) { }
  }
  function mmss(s) {
    s = Math.max(0, Math.ceil(s));
    var h = Math.floor(s / 3600), m = Math.floor(s % 3600 / 60);
    s %= 60;
    return (h ? h + ':' + (m < 10 ? '0' : '') : '') + m + ':' + (s < 10 ? '0' : '') + s;
  }
  function bar() {
    var el = $('tmBar');
    if (!el) { el = document.createElement('div'); el.id = 'tmBar'; el.className = 'tmbar'; document.body.appendChild(el); }
    return el;
  }
  function paintTimers() {
    var el = bar(), now = Date.now();
    timers.forEach(function (t) { if (!t.done && now >= t.end) { t.done = true; beep(); } });
    el.hidden = !timers.length;
    el.innerHTML = timers.map(function (t) {
      return '<div class="tm ' + (t.done ? 'done' : '') + '"><b>' + E(t.name) + '</b><span class="t">' + (t.done ? '时间到' : mmss((t.end - now) / 1000)) + '</span>' +
        '<button data-act="tmStop" data-id="' + t.id + '">' + (t.done ? '知道了' : '取消') + '</button></div>';
    }).join('');
    if (!timers.length && tick) { clearInterval(tick); tick = null; }
  }
  window.clTimer = function (name, sec) {
    timers.push({ id: ++tid, name: name, end: Date.now() + sec * 1000, done: false });
    if (!tick) tick = setInterval(paintTimers, 500);
    try { ac = ac || new (window.AudioContext || window.webkitAudioContext)(); if (ac.resume) ac.resume(); } catch (e) { } // 点按时解锁声音
    paintTimers();
  };
  window.clTimerStop = function (id) { timers = timers.filter(function (t) { return t.id !== id; }); paintTimers(); };
  /* ---------- 一步一屏 ---------- */
  var wl = null, ck = { i: 0, ing: false, name: '' };
  function lock() {
    try { if (navigator.wakeLock) navigator.wakeLock.request('screen').then(function (l) { wl = l; }, function () { }); } catch (e) { }
    if (window.AndroidScreen && AndroidScreen.keepOn) { try { AndroidScreen.keepOn(true); } catch (e) { } }
  }
  function unlock() {
    try { if (wl) { wl.release(); wl = null; } } catch (e) { }
    if (window.AndroidScreen && AndroidScreen.keepOn) { try { AndroidScreen.keepOn(false); } catch (e) { } }
  }
  document.addEventListener('visibilitychange', function () {
    var o = $('cookMode');
    if (o && !o.hidden && document.visibilityState === 'visible') lock();
  });
  function cur() { var rs = CL[ck.name]; return rs && rs[Math.min(clPick, rs.length - 1)]; }
  function ingRows(rows) {
    return '<ul class="ing">' + rows.map(function (x) { return '<li><span>' + E(x[0]) + '</span><span>' + E(clScale(x[1] || '适量', window.clK)) + '</span></li>'; }).join('') + '</ul>';
  }
  function paintCook() {
    var r = cur(), o = $('cookMode'), n = r.steps.length, i = ck.i, last = i >= n, body;
    if (ck.ing) {
      body = '<div class="ck-ing"><h3>用料 <small>份量 ×' + (window.clK === 0.5 ? '½' : window.clK) + '</small></h3>' + (r.ing.length ? ingRows(r.ing) : '') +
        (r.sea.length ? '<h4 class="cl-h">调料</h4>' + ingRows(r.sea) : '') + '</div>';
    } else if (last) {
      body = '<div class="ck-step"><p class="ck-n">做完了</p><p class="ck-t">' + E(ck.name) + ' 做好了，开饭。</p>' +
        '<div class="ck-tm"><button class="btn" data-act="madeOpen">记一笔：做过了</button></div>' +
        (r.tips.length ? '<h4 class="cl-h">窍门</h4><ul class="cl-tips">' + r.tips.map(function (t) { return '<li>' + E(t) + '</li>'; }).join('') + '</ul>' : '') + '</div>';
    } else {
      var tms = clTimes(r.steps[i]);
      body = '<div class="ck-step"><p class="ck-n">第 ' + (i + 1) + ' 步，共 ' + n + ' 步</p><p class="ck-t">' + E(r.steps[i]) + '</p>' +
        (tms.length ? '<div class="ck-tm">' + tms.map(function (t) {
          return '<button class="btn" data-act="tmStart" data-s="' + t.sec + '" data-n="' + E(ck.name + ' 第' + (i + 1) + '步') + '">计时 ' + t.label + '</button>';
        }).join('') + '</div>' : '') +
        (i < n - 1 ? '<p class="ck-next">下一步：' + E(r.steps[i + 1].slice(0, 28)) + (r.steps[i + 1].length > 28 ? '…' : '') + '</p>' : '') + '</div>';
    }
    o.innerHTML = '<div class="ck-top"><button class="back" data-act="ckClose" aria-label="退出做饭模式">×</button><b>' + E(ck.name) + '</b><button class="swap" data-act="ckIng">' + (ck.ing ? '回到步骤' : '看用料') + '</button></div>' +
      '<div class="ck-prog"><i style="width:' + Math.round(Math.min(i, n) / n * 100) + '%"></i></div><div class="ck-main">' + body + '</div>' +
      '<div class="ck-nav"><button class="btn" data-act="ckPrev"' + (i <= 0 && !ck.ing ? ' disabled' : '') + '>上一步</button><button class="btn primary" data-act="ckNext">' + (last ? '退出' : i === n - 1 ? '做完了' : '下一步') + '</button></div>';
  }
  window.clCookOpen = function (name) {
    ck = { i: 0, ing: false, name: name };
    var o = $('cookMode');
    if (!o) {
      o = document.createElement('div'); o.id = 'cookMode'; o.className = 'cookm'; document.body.appendChild(o);
      var x0 = null;
      o.addEventListener('touchstart', function (e) { x0 = e.touches[0].clientX; }, { passive: true });
      o.addEventListener('touchend', function (e) {
        if (x0 === null) return;
        var dx = e.changedTouches[0].clientX - x0; x0 = null;
        if (Math.abs(dx) > 70) { if (dx < 0) window.clCookAct.ckNext(); else window.clCookAct.ckPrev(); }
      }, { passive: true });
    }
    o.hidden = false; lock(); paintCook();
  };
  window.clCookAct = {
    ckClose: function () { $('cookMode').hidden = true; unlock(); renderSheet(); },
    ckIng: function () { ck.ing = !ck.ing; paintCook(); },
    ckPrev: function () { if (ck.ing) { ck.ing = false; } else if (ck.i > 0) { ck.i--; } paintCook(); },
    ckNext: function () {
      var r = cur();
      if (ck.ing) { ck.ing = false; paintCook(); return; }
      if (ck.i >= r.steps.length) return window.clCookAct.ckClose();
      clDone[ck.i] = true; ck.i++; paintCook();
    },
    tmStart: function (el) { clTimer(el.getAttribute('data-n'), +el.getAttribute('data-s')); toast('开始计时'); },
    tmStop: function (el) { clTimerStop(+el.getAttribute('data-id')); }
  };
  Object.keys(window.clCookAct).forEach(function (k) { ACTS[k] = window.clCookAct[k]; });
})();
