/* 好好吃饭 9.0：菜名目录 + 各平台一键搜索 + 自己存的链接。
   data.js 提供 DISHES（[菜名,类型序号,菜系序号]）、TYPES、CUISINES、R（旧版带用料和营养的菜）。
   fav2/shop2/cooked2/customRecipes3/weekPlan87 沿用旧版的键，覆盖安装后数据还在。 */
var APP_VER = '9.3', APP_CODE = 24; // 和 AndroidManifest.xml 保持一致；只在浏览器里预览、没有原生桥时用
var LS = {
  get: function (k, d) { try { var v = JSON.parse(localStorage.getItem(k)); return v == null ? d : v; } catch (e) { return d; } },
  set: function (k, v) { try { localStorage.setItem(k, JSON.stringify(v)); } catch (e) { toast('保存失败，手机空间可能不足'); } }
};
function E(s) { return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]; }); }
function $(id) { return document.getElementById(id); }

var ICONS = {
  home: '<path d="M4 11l8-7 8 7v9h-5v-6H9v6H4z"/>',
  grid: '<path d="M4 4h7v7H4zM13 4h7v7h-7zM4 13h7v7H4zM13 13h7v7h-7z"/>',
  heart: '<path d="M12 20s-8-5-8-11a4.500 4.500 0 0 1 8-2.800A4.500 4.500 0 0 1 20 9c0 6-8 11-8 11z"/>',
  sun: '<path d="M5 5h14v15H5zM5 10h14M9 3v4M15 3v4"/>',
  fridge: '<path d="M6 3h12v18H6zM6 10h12M9 6v1.500M9 13v3"/>',
  cart: '<path d="M3 5h3l2 11h10l2-8H7M9 20h.01M17 20h.01"/>',
  gear: '<circle cx="12" cy="12" r="3"/><path d="M12 3v3M12 18v3M3 12h3M18 12h3M5.600 5.600l2.100 2.100M16.300 16.300l2.100 2.100M18.400 5.600l-2.100 2.100M7.700 16.300l-2.100 2.100"/>'
};
function icon(n, fill) { return '<svg viewBox="0 0 24 24" fill="' + (fill ? 'currentColor' : 'none') + '" stroke="currentColor" stroke-width="1.800" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">' + (ICONS[n] || '') + '</svg>'; }

/* ---------- 平台 ---------- */
var PLATFORMS = [
  { id: 'douyin', name: '抖音', mark: '抖', color: '#161823', note: '短视频', app: 'snssdk1128://search/result?keyword=', web: 'https://www.douyin.com/search/' },
  { id: 'xhs', name: '小红书', mark: '红', color: '#E6233C', note: '图文笔记', app: 'xhsdiscover://search/result?keyword=', web: 'https://www.xiaohongshu.com/search_result?keyword=' },
  { id: 'bili', name: 'B 站', mark: 'B', color: '#E8739A', note: '长视频', app: 'bilibili://search?keyword=', web: 'https://m.bilibili.com/search?keyword=' },
  { id: 'kuaishou', name: '快手', mark: '快', color: '#F2690D', note: '短视频', web: 'https://www.kuaishou.com/search/video?searchKey=' },
  { id: 'xcf', name: '下厨房', mark: '下', color: '#C8553D', note: '菜谱', web: 'https://www.xiachufang.com/search/?keyword=' },
  { id: 'youtube', name: 'YouTube', mark: 'Y', color: '#D21A1A', note: '长视频', web: 'https://www.youtube.com/results?search_query=' },
  { id: 'google', name: 'Google', mark: 'G', color: '#3A70D8', note: '全网', web: 'https://www.google.com/search?q=' }
];
var LINK_HOSTS = [
  [/douyin\.com|iesdouyin\.com/, '抖音'], [/xiaohongshu\.com|xhslink\.com/, '小红书'], [/bilibili\.com|b23\.tv/, 'B 站'],
  [/kuaishou\.com|gifshow\.com|chenzhongtech\.com/, '快手'], [/xiachufang\.com/, '下厨房'], [/youtube\.com|youtu\.be/, 'YouTube'],
  [/weixin\.qq\.com/, '微信'], [/zhihu\.com/, '知乎'], [/weibo\.(com|cn)/, '微博']
];
var MODS = ['做法', '家常', '正宗', '快手', '减脂', '空气炸锅'];
var prefs = LS.get('prefs9', { off: [], web: [] });
function platformsOn() { return PLATFORMS.filter(function (p) { return prefs.off.indexOf(p.id) < 0; }); }
function openPlatform(id, query, forceWeb) {
  var p = PLATFORMS.filter(function (x) { return x.id === id; })[0];
  if (!p) return;
  var q = encodeURIComponent(query);
  var useApp = p.app && !forceWeb && prefs.web.indexOf(id) < 0;
  var webUrl = p.web + q;
  if (window.AndroidNav) AndroidNav.open(useApp ? p.app + q : '', webUrl, useApp ? query : '');
  else window.open(webUrl, '_blank');
  if (useApp) toast('已复制「' + query + '」，没搜到可以直接粘贴');
}
function openUrl(u) { if (window.AndroidNav) AndroidNav.open('', u, ''); else window.open(u, '_blank'); }

/* ---------- 数据 ---------- */
var fav = new Set(LS.get('fav2', []));
var shop = LS.get('shop2', []);
var shopDone = new Set(LS.get('shopDone9', []));
var links = LS.get('links9', {});
var customDishes = LS.get('customDishes9', []);
var recents = LS.get('recents9', []);
var userRecipes = LS.get('customRecipes3', []);
userRecipes.forEach(function (r) { if (r && r.name && !R.some(function (x) { return x.name === r.name; })) { r.custom = true; R.push(r); } });
var byR = {}; R.forEach(function (r) { byR[r.name] = r; });
var ALL = [], byName = {};
function addDish(name, t, c, extra) {
  if (byName[name]) return byName[name];
  var r = byR[name];
  var tg = typeof TAGS !== 'undefined' && TAGS[name] ? ' ' + TAGS[name].replace(/[|,]/g, ' ') : ''; // 按食材搜：标过的菜也能搜到
  if (CL[name]) tg += ' ' + CL[name].map(function (x) { return x.aka.join(' '); }).join(' ');
  var d = { name: name, t: t, c: c, r: r, hay: name + tg +(r ? ' ' + (r.main || '') + ' ' + (r.ingredients || []).map(function (i) { return i[0]; }).join(' ') : ''), mine: !!extra };
  ALL.push(d); byName[name] = d; return d;
}
function rebuildDishes() {
  DISHES.forEach(function (x) { addDish(x[0], x[1], x[2]); });
  R.forEach(function (r) { addDish(r.name, -1, -1, r.custom); });
  customDishes.forEach(function (n) { addDish(n, -1, -1, true); });
}
/* 村驴（抖音博主）视频整理出的做法：CUNLV = {菜名: [做法, …]}，赞多的在前 */
var CL = typeof CUNLV !== 'undefined' ? CUNLV : {};
var CL_CATS = ['热菜', '凉菜', '汤羹', '主食', '面点', '小吃', '早餐', '腌菜酱料', '甜品饮品'];
var clPick = 0, clDone = {};
function saveLinks() { LS.set('links9', links); }
function linkCount(n) { return (links[n] || []).length; }

/* ---------- 搜索 ---------- */
var SYN = [['番茄', '西红柿'], ['土豆', '马铃薯', '洋芋'], ['红薯', '地瓜', '番薯'], ['包菜', '卷心菜', '圆白菜', '手撕包菜'], ['香菜', '芫荽'], ['虾仁', '虾'], ['青椒', '辣椒'], ['鸡胸', '鸡胸肉'], ['意面', '意大利面'], ['奶酪', '芝士'], ['玉米', '苞米'], ['花菜', '菜花', '花椰菜'], ['茄子', '矮瓜'], ['面条', '面']];
function variants(t) {
  for (var i = 0; i < SYN.length; i++) if (SYN[i].indexOf(t) >= 0) return SYN[i];
  return [t];
}
function isSubseq(q, s) { var i = 0; for (var j = 0; j < s.length && i < q.length; j++) if (s[j] === q[i]) i++; return i === q.length; }
function searchDishes(q) {
  var tokens = q.trim().toLowerCase().split(/\s+/).filter(Boolean);
  if (!tokens.length) return [];
  var out = [];
  ALL.forEach(function (d) {
    var score = 0, name = d.name.toLowerCase(), hay = d.hay.toLowerCase();
    for (var i = 0; i < tokens.length; i++) {
      var vs = variants(tokens[i]), s = 0;
      for (var k = 0; k < vs.length; k++) {
        var at = name.indexOf(vs[k]);
        var own = vs[k] === tokens[i] ? 5 : 0; // 用户原话排在同义词前面
        if (at === 0) s = Math.max(s, (name.length === vs[k].length ? 100 : 60) + own);
        else if (at > 0) s = Math.max(s, 40 + own);
        else if (vs[k].length >= 2 && hay.indexOf(vs[k]) >= 0) s = Math.max(s, 15);
      }
      if (!s && tokens[i].length >= 2 && isSubseq(tokens[i], name)) s = 6;
      if (!s) return;
      score += s;
    }
    if (linkCount(d.name)) score += 8;
    if (fav.has(d.name)) score += 5;
    out.push({ d: d, s: score - d.name.length * 0.3 });
  });
  out.sort(function (a, b) { return b.s - a.s; });
  return out.map(function (x) { return x.d; });
}
function highlight(name, q) {
  var ts = q.trim().split(/\s+/).filter(Boolean), html = E(name);
  ts.forEach(function (t) { variants(t).forEach(function (v) { var ev = E(v); if (ev && html.indexOf(ev) >= 0 && html.indexOf('<mark>') < 0) html = html.split(ev).join('<mark>' + ev + '</mark>'); }); });
  return html;
}
function dishRow(d, q) {
  var n = linkCount(d.name), side = [];
  if (n) side.push('<span class="has">' + n + ' 个链接</span>');
  if (fav.has(d.name)) side.push('<span class="heart">♥</span>');
  if (CL[d.name]) side.push('<span class="has">有做法</span>');
  else if (!n && d.t >= 0) side.push(E(TYPES[d.t]));
  return '<li><button class="dish-row" data-open="' + E(d.name) + '"><b>' + (q ? highlight(d.name, q) : E(d.name)) + '</b><small>' + side.join(' ') + '</small></button></li>';
}
/* 长列表分批渲染 */
function renderList(box, items, q) {
  var shown = 0;
  box.innerHTML = '<ul class="dish-list"></ul><button class="more" hidden>再看 80 道</button>';
  var ul = box.firstChild, more = box.lastChild;
  function step() {
    ul.insertAdjacentHTML('beforeend', items.slice(shown, shown + 80).map(function (d) { return dishRow(d, q); }).join(''));
    shown += 80;
    more.hidden = shown >= items.length;
  }
  more.onclick = step;
  step();
}

/* ---------- 页面切换 ---------- */
var NAV = [['Home', 'home', '搜索'], ['Pantry', 'fridge', '食材'], ['Browse', 'grid', '分类'], ['Fav', 'heart', '收藏'], ['Shop', 'cart', '清单']];
var current = 'Home';
function goPage(p) {
  current = p;
  document.querySelectorAll('.page').forEach(function (s) { s.classList.toggle('active', s.id === 'p' + p); });
  document.querySelectorAll('.navin button').forEach(function (b) { b.classList.toggle('active', b.getAttribute('data-p') === p); });
  if (p === 'Pantry' && window.renderPantry) renderPantry();
  if (p === 'Browse') renderBrowse();
  if (p === 'Fav') renderFav();
  if (p === 'Shop') renderShop();
  if (p === 'Set') renderSettings();
  if (p === 'Home') renderIdle();
}
function toast(msg) {
  var t = $('toast'); t.textContent = msg; t.hidden = false;
  clearTimeout(toast.timer); toast.timer = setTimeout(function () { t.hidden = true; }, 2600);
}

/* ---------- 首页 ---------- */
function renderIdle() {
  var saved = Object.keys(links).filter(function (n) { return links[n].length; }).slice(-8).reverse();
  var html = updateCard() + webCard() + (window.homePantryCard ? homePantryCard() : '');
  var clN = Object.keys(CL).length;
  if (clN) html += '<button class="home-card" data-act="goCunlv"><b>村驴的家常菜 ' + clN + ' 道</b><span>从他的抖音视频整理的用料和步骤，做饭时照着看</span></button>';
  if (recents.length) html += '<h2 class="block-title">最近搜过</h2><div class="chips">' + recents.map(function (n) { return '<button class="chip" data-open="' + E(n) + '">' + E(n) + '</button>'; }).join('') + '</div>';
  if (saved.length) html += '<h2 class="block-title">存了链接的菜</h2><ul class="dish-list">' + saved.map(function (n) { return dishRow(byName[n] || addDish(n, -1, -1, true)); }).join('') + '</ul>';
  else html += '<p class="tip">在抖音、小红书里点分享，选“存到好好吃饭”，做法就存到菜名下面了。</p>';
  html += '<div class="head-row"><h2 class="block-title">今天看看这几道</h2><button class="swap" data-act="reroll">换一批</button></div><ul class="dish-list">' + picks().map(function (d) { return dishRow(d); }).join('') + '</ul>';
  html += '<p class="count">菜名库共 ' + ALL.length + ' 道，搜不到的菜也能直接搜到各平台。</p>';
  $('homeIdle').innerHTML = html;
}
/* 只从旧版核对过的家常菜里挑，词库里生僻的地方菜不往首页放 */
var pickCache = null;
function picks() {
  if (pickCache) return pickCache;
  var pool = ALL.filter(function (d) { return d.r && d.r.sourceChecked; });
  if (pool.length < 6) pool = ALL;
  var out = [], seen = {};
  while (out.length < 6 && pool.length) { var d = pool[Math.floor(Math.random() * pool.length)]; if (!seen[d.name]) { seen[d.name] = 1; out.push(d); } }
  return (pickCache = out);
}
function onQuery() {
  var q = $('q').value.trim();
  $('qClear').hidden = !q;
  $('homeIdle').hidden = !!q;
  var box = $('homeResults'); box.hidden = !q;
  if (!q) { renderIdle(); return; }
  var res = searchDishes(q);
  var exact = byName[q];
  box.innerHTML = (exact ? '' : '<button class="search-all" data-open="' + E(q) + '">到各平台搜 <b>' + E(q) + '</b></button>') + '<p class="count">' + (res.length ? '找到 ' + res.length + ' 道' : '菜名库里没有这道菜，可以直接到各平台搜') + '</p><div id="resList"></div>';
  if (res.length) renderList($('resList'), res, q);
}

/* ---------- 分类 ---------- */
var INGR = [
  ['猪肉', /猪|五花|排骨|肉丝|肉末|肉片|里脊|肘|腊肉|腊肠|叉烧|回锅|红烧肉|东坡|狮子头|肉丸|肉饼|培根|火腿/], ['牛肉', /牛/], ['羊肉', /羊/], ['鸡肉', /鸡(?!蛋)|宫保/], ['鸭鹅', /鸭(?!蛋)|鹅/],
  ['鱼', /鱼(?!香)|鲈|鳕|鲫|鲤|鳜|鲳/], ['虾蟹', /虾|蟹|小龙/], ['贝类海鲜', /贝|蛤|蚝|蛏|鱿|章鱼|墨鱼|海参|鲍|海鲜|螺/], ['鸡蛋', /蛋(?!糕|挞|黄酥|卷)/], ['豆腐豆制品', /豆腐|腐竹|千张|豆皮|豆干|香干/],
  ['土豆', /土豆|马铃薯|薯条|薯/], ['番茄', /番茄|西红柿/], ['茄子', /茄子|茄/], ['青菜', /青菜|白菜|菠菜|油菜|生菜|菜心|油麦|空心菜|芥蓝|娃娃菜|包菜/], ['瓜类', /瓜/], ['豆类', /豆角|四季豆|荷兰豆|毛豆|豌豆|扁豆|刀豆|绿豆|红豆|黄豆|黑豆/],
  ['菌菇', /菇|蘑|木耳|银耳|菌/], ['根茎', /萝卜|藕|山药|芋|南瓜|红薯|笋/], ['米饭', /饭|粥|米/], ['面条', /面(?!包|筋|膜)|粉(?!蒸)|线/], ['饺子包子', /饺|包子|馄饨|云吞|烧麦|馒头|花卷|饼/], ['巧克力', /巧克力|可可/], ['水果', /苹果|香蕉|草莓|芒果|柠檬|橙|桃|梨|葡萄|蓝莓|椰/], ['奶制品', /奶|芝士|奶酪|酸奶|黄油/]
];
var browse = { mode: 'type', pick: null };
function dishesOf(mode, i) {
  if (mode === 'type') return ALL.filter(function (d) { return d.t === i; });
  if (mode === 'cuisine') return ALL.filter(function (d) { return d.c === i; });
  if (mode === 'cunlv') return ALL.filter(function (d) { return CL[d.name] && CL[d.name][0].cat === CL_CATS[i]; }).sort(function (a, b) { return CL[b.name][0].likes - CL[a.name][0].likes; });
  return ALL.filter(function (d) { return INGR[i][1].test(d.name) || (d.r && INGR[i][1].test(d.r.main || '')); });
}
function renderBrowse() {
  var el = $('pBrowse');
  if (browse.pick !== null) {
    var label = browse.mode === 'type' ? TYPES[browse.pick] : browse.mode === 'cuisine' ? CUISINES[browse.pick] : browse.mode === 'cunlv' ? '村驴 · ' + CL_CATS[browse.pick] : INGR[browse.pick][0];
    var items = dishesOf(browse.mode, browse.pick);
    el.innerHTML = '<div class="crumb"><button class="back" data-act="browseBack" aria-label="返回分类">‹</button><h2>' + E(label) + '</h2></div><p class="count">' + items.length + ' 道</p><div id="browseList"></div>';
    renderList($('browseList'), items);
    el.scrollTop = 0;
    return;
  }
  var names = browse.mode === 'type' ? TYPES : browse.mode === 'cuisine' ? CUISINES : browse.mode === 'cunlv' ? CL_CATS : INGR.map(function (x) { return x[0]; });
  var cells = names.map(function (n, i) { return { n: n, i: i, c: dishesOf(browse.mode, i).length }; }).filter(function (x) { return x.c; });
  var modes = [['type', '按类型'], ['cuisine', '按菜系'], ['ingr', '按食材']];
  if (Object.keys(CL).length) modes.push(['cunlv', '村驴']);
  el.innerHTML = '<h1 class="page-title">分类</h1><div class="seg">' + modes.map(function (m) { return '<button data-act="browseMode" data-m="' + m[0] + '" class="' + (browse.mode === m[0] ? 'on' : '') + '">' + m[1] + '</button>'; }).join('') + '</div><div class="cat-grid">' + cells.map(function (x) { return '<button data-act="browsePick" data-i="' + x.i + '"><b>' + E(x.n) + '</b><small>' + x.c + ' 道</small></button>'; }).join('') + '</div>';
}

/* ---------- 收藏 ---------- */
function renderFav() {
  var names = {};
  Object.keys(links).forEach(function (n) { if (links[n].length) names[n] = 1; });
  fav.forEach(function (n) { names[n] = 1; });
  customDishes.forEach(function (n) { names[n] = 1; });
  var list = Object.keys(names).map(function (n) { return byName[n] || addDish(n, -1, -1, true); });
  list.sort(function (a, b) { return linkCount(b.name) - linkCount(a.name); });
  $('pFav').innerHTML = '<h1 class="page-title">收藏</h1>' + (list.length ? '<div id="favList"></div>' : '<div class="empty"><b>还没有收藏</b>点菜名页右上角的“收藏”，或者存一个链接，菜就会出现在这里。</div>');
  if (list.length) renderList($('favList'), list);
}

/* ---------- 详情 ---------- */
var stack = [], curDish = null, curMod = '做法';
function queryOf(name) { return curMod ? name + ' ' + curMod : name; }
function openR(name) {
  name = String(name).trim();
  if (!name) return;
  curDish = name; curMod = LS.get('mod9', '做法'); clPick = 0; clDone = {};
  recents = [name].concat(recents.filter(function (x) { return x !== name; })).slice(0, 10);
  LS.set('recents9', recents);
  var w = $('sheetWrap'); var wasHidden = w.hidden; w.hidden = false;
  w.classList.toggle('enter', wasHidden);
  renderSheet(); w.scrollTop = 0;
  // 被 plan.js 包一层后还会往 #sheet 追加营养估算
}
function hostLabel(u) {
  for (var i = 0; i < LINK_HOSTS.length; i++) if (LINK_HOSTS[i][0].test(u)) return LINK_HOSTS[i][1];
  try { return new URL(u).hostname.replace(/^www\./, ''); } catch (e) { return '链接'; }
}
function renderSheet() {
  var name = curDish, d = byName[name], r = byR[name], ls = links[name] || [], meta = [];
  if (d && d.t >= 0) meta.push(TYPES[d.t]);
  if (d && d.c >= 0) meta.push(CUISINES[d.c]);
  var inLib = !!d;
  var html = '<div class="sheet-top"><button class="back" data-act="closeSheet" aria-label="返回">‹</button><button class="fav-btn ' + (fav.has(name) ? 'on' : '') + '" data-act="fav">' + icon('heart', fav.has(name)) + (fav.has(name) ? '已收藏' : '收藏') + '</button></div>';
  html += '<h1 class="dish-name">' + E(name) + '</h1>' + (meta.length ? '<p class="dish-meta">' + E(meta.join('，')) + '</p>' : '');
  html += cunlvHTML(name);
  html += '<div class="section-head"><h3>' + (CL[name] ? '再去搜搜别人的' : '去哪儿搜') + '</h3></div><div class="mods">' + MODS.map(function (m) { return '<button class="chip ' + (curMod === m ? 'on' : '') + '" data-act="mod" data-m="' + m + '">' + m + '</button>'; }).join('') + '<button class="chip ' + (!curMod ? 'on' : '') + '" data-act="mod" data-m="">只搜菜名</button></div>';
  html += '<div class="plat-grid">' + platformsOn().map(function (p) { return '<button class="plat" data-plat="' + p.id + '"><i style="background:' + p.color + '">' + p.mark + '</i><span><b>' + E(p.name) + '</b><small>' + (p.note) + '</small></span></button>'; }).join('') + '</div><p class="hint">长按用网页打开。搜的是“' + E(queryOf(name)) + '”。</p>';
  html += '<div class="section-head"><h3>我存的链接</h3></div>';
  if (ls.length) html += ls.map(function (l, i) { return '<div class="link-row"><button class="link-open" data-link="' + i + '"><b>' + E(l.t || l.u) + '</b><small>' + E(l.p || hostLabel(l.u)) + '</small></button><button class="link-del" data-del="' + i + '" aria-label="删除这个链接">×</button></div>'; }).join('');
  if (r && r.source && /^https?:/.test(r.source)) html += '<div class="link-row"><button class="link-open" data-url="' + E(r.source) + '"><b>之前核对过的做法</b><small>' + E(hostLabel(r.source)) + '</small></button></div>';
  html += '<div class="btn-row"><button class="btn" data-act="addLink">粘贴链接存到这里</button></div>';
  html += '<div class="btn-row"><button class="btn" data-act="toWeek">排进一周</button>' + (r && r.ingredients && r.ingredients.length ? '<button class="btn" data-act="toShop">用料加入清单</button>' : '') + (inLib ? '' : '<button class="btn" data-act="addCustom">加入我的菜名</button>') + (d && d.mine && customDishes.indexOf(name) >= 0 ? '<button class="btn" data-act="delCustom">从我的菜名移除</button>' : '') + '</div>';
  html += window.pantrySheetHTML ? pantrySheetHTML(name) : '';
  if (r && r.ingredients && r.ingredients.length) html += '<div class="section-head"><h3>用料</h3><small>供买菜参考</small></div><ul class="ing">' + r.ingredients.map(function (i) { return '<li><span>' + E(i[0]) + '</span><span>' + E(i[1]) + '</span></li>'; }).join('') + '</ul>';
  if (r && r.custom && r.steps && r.steps.length) html += '<div class="section-head"><h3>我写的步骤</h3></div><ol class="steps">' + r.steps.map(function (s) { return '<li>' + E(s) + '</li>'; }).join('') + '</ol>';
  $('sheet').innerHTML = html;
}
function ingList(rows) {
  return '<ul class="ing">' + rows.map(function (i) { return '<li><span>' + E(i[0]) + '</span><span>' + E(i[1] || '适量') + '</span></li>'; }).join('') + '</ul>';
}
function cunlvHTML(name) {
  var rs = CL[name];
  if (!rs) return '';
  var r = rs[Math.min(clPick, rs.length - 1)], h = '<div class="cl">';
  h += '<div class="section-head"><h3>村驴的做法</h3><small>' + E(r.date) + '</small></div>';
  if (rs.length > 1) h += '<div class="mods">' + rs.map(function (x, i) { return '<button class="chip ' + (i === clPick ? 'on' : '') + '" data-act="clPick" data-i="' + i + '">做法 ' + (i + 1) + '</button>'; }).join('') + '</div>';
  if (r.sum) h += '<p class="cl-sum">' + E(r.sum) + '</p>';
  var info = [r.serves, r.time].filter(Boolean);
  if (info.length) h += '<p class="dish-meta">' + E(info.join('，')) + '</p>';
  if (r.ing.length) h += '<h4 class="cl-h">用料</h4>' + ingList(r.ing);
  if (r.sea.length) h += '<h4 class="cl-h">调料</h4>' + ingList(r.sea);
  h += '<h4 class="cl-h">步骤 <small>做完一步点一下划掉</small></h4><ol class="steps cl-steps">' + r.steps.map(function (s, i) { return '<li data-step="' + i + '" class="' + (clDone[i] ? 'done' : '') + '">' + E(s) + '</li>'; }).join('') + '</ol>';
  if (r.tips.length) h += '<h4 class="cl-h">窍门</h4><ul class="cl-tips">' + r.tips.map(function (t) { return '<li>' + E(t) + '</li>'; }).join('') + '</ul>';
  if (r.conf === '低') h += '<p class="hint">这条视频的语音转写比较乱，整理可能不全，最好对着原视频看。</p>';
  h += '<div class="btn-row"><button class="btn" data-url="' + E(r.url) + '">看原视频</button>' + (r.ing.length ? '<button class="btn" data-act="clShop">用料加入清单</button>' : '') + '</div>';
  return h + '</div>';
}
function closeSheet() { $('sheetWrap').hidden = true; curDish = null; refreshBehind(); }
function refreshBehind() { if (current === 'Fav') renderFav(); if (current === 'Home') { if ($('q').value.trim()) onQuery(); else renderIdle(); } }

/* ---------- 存链接 ---------- */
function parseShare(text) {
  text = String(text || '');
  var m = text.match(/https?:\/\/[^\s，。、！？）)】」"'<>一-龥]+/);
  var url = m ? m[0].replace(/[.,;:!?]+$/, '') : '';
  var title = url ? text.replace(m[0], ' ') : text;
  // 抖音、小红书分享文字里的口令和引导语都不是标题
  title = title
    .replace(/^[\s\d.]+/, '')
    .replace(/复制打开[^，,\s]{0,6}[，,]\s*看看【[^】]*】/g, ' ')
    .replace(/复制(此|本条|这条)?(链接|信息|内容)?[，,]?\s*打开【?[^】\s]{0,8}】?\s*(App|APP)?\s*(查看精彩内容|直接观看视频)?[！!。]?/g, ' ')
    .replace(/[^\s]*发布了一篇小红书笔记，快来看吧！?/g, ' ')
    .replace(/[\u{1F300}-\u{1FAFF}]\s*\S{1,12}\s*[\u{1F300}-\u{1FAFF}]/gu, ' ')
    .replace(/[\u{1F300}-\u{1FAFF}☀-➿]/gu, ' ')
    .replace(/【|】/g, ' ')
    .replace(/\S*[a-zA-Z]:\/\s*\S*/g, ' ')
    .replace(/\S+@\S+/g, ' ')
    .replace(/\d+\/\d+/g, ' ')
    .replace(/#\s*\S+/g, ' ')
    .replace(/\s+/g, ' ').trim();
  return { url: url, title: title.slice(0, 80), platform: url ? hostLabel(url) : '' };
}
function guessDish(text) {
  var best = '';
  ALL.forEach(function (d) { if (d.name.length > best.length && d.name.length >= 2 && text.indexOf(d.name) >= 0) best = d.name; });
  return best;
}
var linkDraft = null;
function openLinkModal(shared, presetDish) {
  var p = parseShare(shared);
  linkDraft = { dish: presetDish || guessDish(p.title + ' ' + shared) || '', fromShare: !presetDish && !!shared };
  $('modalBody').innerHTML = '<h3>存到哪道菜</h3>' +
    '<label class="field">链接和文字<textarea id="lkRaw" rows="2">' + E(p.url) + '</textarea></label>' +
    '<label class="field">标题<input id="lkTitle" value="' + E(p.title) + '" placeholder="给这个做法起个名字"></label>' +
    '<label class="field">菜名<input id="lkDish" value="' + E(linkDraft.dish) + '" placeholder="搜菜名，没有的话直接写"></label>' +
    '<div class="pick-list" id="lkPick"></div>' +
    '<p class="small" id="lkErr"></p>' +
    '<div class="btn-row"><button class="btn" data-act="modalClose">取消</button><button class="btn primary" data-act="lkSave">保存</button></div>';
  showModal();
  $('lkDish').oninput = pickRefresh;
  $('lkRaw').oninput = function () { var x = parseShare($('lkRaw').value); if (x.url && !$('lkTitle').value) $('lkTitle').value = x.title; };
  pickRefresh();
}
function pickRefresh() {
  var q = $('lkDish').value.trim();
  $('lkPick').innerHTML = q ? '<ul class="dish-list">' + searchDishes(q).slice(0, 12).map(function (d) { return '<li><button class="dish-row ' + (d.name === q ? 'on' : '') + '" data-pick="' + E(d.name) + '"><b>' + E(d.name) + '</b></button></li>'; }).join('') + '</ul>' : '';
}
function saveLink() {
  var raw = $('lkRaw').value, parsed = parseShare(raw), dish = $('lkDish').value.trim();
  if (!parsed.url) { $('lkErr').textContent = '没有找到链接，请粘贴以 http 开头的地址。'; return; }
  if (!dish) { $('lkErr').textContent = '请写上菜名。'; $('lkDish').focus(); return; }
  if (!byName[dish]) { customDishes.push(dish); LS.set('customDishes9', customDishes); addDish(dish, -1, -1, true); }
  var list = links[dish] || (links[dish] = []);
  if (list.some(function (l) { return l.u === parsed.url; })) { $('lkErr').textContent = '这个链接已经存在这道菜下面了。'; return; }
  list.unshift({ u: parsed.url, t: $('lkTitle').value.trim() || parsed.title || parsed.platform + '上的做法', p: parsed.platform, at: Date.now() });
  saveLinks();
  var fromShare = linkDraft.fromShare;
  closeModal();
  toast('已存到「' + dish + '」');
  if (curDish === dish) renderSheet();
  refreshBehind();
  if (fromShare && window.AndroidNav) setTimeout(function () { AndroidNav.back(); }, 900);
}
window.onShared = function (text) { openLinkModal(text); };

/* ---------- 弹窗 ---------- */
function showModal() { $('modal').hidden = false; }
function closeModal() { $('modal').hidden = true; $('modalBody').innerHTML = ''; }
function weekModal() {
  var days = ['周一', '周二', '周三', '周四', '周五', '周六', '周日'];
  $('modalBody').innerHTML = '<h3>排进哪一天</h3><div class="day-grid">' + days.map(function (d, i) { return '<span>' + d + '</span><button class="btn" data-week="' + i + ',0">午餐</button><button class="btn" data-week="' + i + ',1">晚餐</button>'; }).join('') + '</div><div class="btn-row"><button class="btn" data-act="modalClose">取消</button></div>';
  showModal();
}

/* ---------- 清单 ---------- */
function saveShop() { LS.set('shop2', shop); LS.set('shopDone9', Array.from(shopDone)); }
function renderShop() {
  var html = '<h1 class="page-title">买菜清单</h1><div class="add-row"><input id="shopInput" placeholder="加一样要买的"><button class="btn primary" data-act="shopAdd">加入</button></div>' +
    (shopDone.size ? '<button class="btn bought" data-act="shopToPantry">买回来了：把勾选的 ' + shopDone.size + ' 样放进食材</button>' : '');
  if (!shop.length) html += '<div class="empty"><b>清单是空的</b>在菜名页点“用料加入清单”，或者在上面直接写。</div>';
  shop.forEach(function (g, gi) {
    html += '<div class="shop-group"><header><h3>' + E(g.name) + '</h3><button class="link-del" data-shopdel="' + gi + '" aria-label="删除这组">×</button></header>' + (g.items || []).map(function (it, ii) {
      var key = gi + '|' + g.name + '|' + it[0]; var done = shopDone.has(key);
      return '<label class="shop-item ' + (done ? 'done' : '') + '"><input type="checkbox" data-shopitem="' + E(key) + '"' + (done ? ' checked' : '') + '><span>' + E(it[0]) + '</span><em>' + E(it[1]) + '</em></label>';
    }).join('') + '</div>';
  });
  $('pShop').innerHTML = html;
}

/* ---------- 设置 ---------- */
function renderSettings() {
  var name = APP_VER, code = APP_CODE;
  try { if (window.AndroidUpdate) { name = AndroidUpdate.versionName() || name; code = AndroidUpdate.versionCode() || code; } } catch (e) {}
  var iconKey = 'Orange'; try { if (window.AndroidLauncher) iconKey = AndroidLauncher.current(); } catch (e) {}
  $('pSet').innerHTML = '<div class="crumb"><button class="back" data-act="setBack" aria-label="返回">‹</button><h2>设置</h2></div>' +
    '<div class="set-group"><h3>版本更新</h3><p class="small">当前版本 ' + E(name) + '（' + code + '）' + (webVer() ? '，内容版本 ' + E(fmtVer(webVer())) : '') + '。打开 App 会自动检查；菜谱和界面的小更新会自己下载，不用装安装包。</p><div class="btn-row"><button class="btn" data-act="checkUpdate">检查更新</button></div><div id="updateBox" class="small"></div></div>' +
    (window.themeSettingsHTML ? themeSettingsHTML() : '') +
    '<div class="set-group"><h3>搜索平台</h3><p class="small">“打开方式”选网页后，就不会再尝试打开 App。某个 App 跳过去没有搜索结果时可以改这里。</p>' +
    PLATFORMS.map(function (p) {
      var st = prefs.off.indexOf(p.id) >= 0 ? 'off' : (p.app && prefs.web.indexOf(p.id) < 0 ? 'app' : 'web');
      return '<div class="set-row"><b>' + E(p.name) + '</b><select data-platset="' + p.id + '" aria-label="' + E(p.name) + '打开方式">' + (p.app ? '<option value="app"' + (st === 'app' ? ' selected' : '') + '>打开 App</option>' : '') + '<option value="web"' + (st === 'web' ? ' selected' : '') + '>' + (p.app ? '用网页' : '显示') + '</option><option value="off"' + (st === 'off' ? ' selected' : '') + '>不显示</option></select></div>';
    }).join('') + '</div>' +
    '<div class="set-group"><h3>数据备份</h3><p class="small">收藏、链接、清单和一周计划都存在这台手机上。换手机或卸载前先导出。</p><div class="btn-row"><button class="btn" data-act="backup">导出备份</button><button class="btn" data-act="restore">恢复备份</button></div><p class="small" id="backupStatus"></p></div>' +
    '<div class="set-group"><h3>桌面图标</h3><div class="chips">' + [['Orange', '橙色'], ['Green', '绿色'], ['Night', '夜色'], ['Frieren', '芙莉莲']].map(function (x) { return '<button class="chip ' + (iconKey === x[0] ? 'on' : '') + '" data-iconkey="' + x[0] + '">' + x[1] + '</button>'; }).join('') + '</div></div>' +
    '<div class="set-group"><h3>菜名和字体来源</h3><p class="small">共 ' + ALL.length + ' 道菜名，来自旧版菜谱、HowToCook（Unlicense）、清华 THUOCL 饮食词库（MIT）和人工补充。一周计划的营养是按用料估算的参考值。字体为霞鹜文楷（SIL OFL 1.1）。</p></div>';
}
var FEED_URL = 'https://raw.githubusercontent.com/galares/my-home-kitchen-recipes/main/haohaochifan-update.json';
/* 更新：每次打开 App 自动查一次（12 小时内不重复），有新版就在首页顶上提示；设置页也能手动查。
   结果存 upd9；是否更新以“当前安装的版本号”现算，装好新版后提示自己消失。 */
var updSilent = false;
function curCode() { try { return window.AndroidUpdate ? AndroidUpdate.versionCode() : APP_CODE; } catch (e) { return APP_CODE; } }
function renderUpdateBox(box, app, newer) {
  if (!newer) { box.innerHTML = '<p class="update-ok">已是最新版本。</p>'; return; }
  box.innerHTML = '<p>新版本 ' + E(app.versionName) + '：' + E(app.notes || '') + '</p><button class="btn primary" id="doInstall">下载并安装</button>';
  $('doInstall').onclick = function () {
    box.insertAdjacentHTML('beforeend', '<p>正在下载，下载完会弹出系统的安装界面。第一次要在系统里允许“安装未知应用”。</p>');
    if (window.AndroidUpdate) AndroidUpdate.install(app.apkUrl, app.sha256 || ''); else openUrl(app.apkUrl);
  };
}
function updateCard() {
  var u = LS.get('upd9', null);
  if (!u || !u.app || (+u.app.versionCode || 0) <= curCode()) return '';
  return '<button class="home-card update" data-act="goUpdate"><b>有新版本 ' + E(u.app.versionName) + '</b><span>' + E(u.app.notes || '点这里更新') + '</span></button>';
}
function autoCheckUpdate() {
  if (!window.AndroidUpdate) return;
  var u = LS.get('upd9', null);
  // 有内容热更新（9.3 起）时每次打开都查一次，更新源只有 1KB；没有就 12 小时查一次
  if (!window.AndroidWeb && u && Date.now() - u.at < 12 * 36e5) return;
  updSilent = true; try { AndroidUpdate.check(FEED_URL); } catch (e) { updSilent = false; }
}
window.onAppUpdateInfo = function (text) {
  var silent = updSilent; updSilent = false;
  var feed = null, app = null; try { feed = JSON.parse(text); app = feed.app; } catch (e) {}
  checkWeb(feed && feed.web);
  var box = $('updateBox');
  if (!app || !app.versionCode || !app.apkUrl) { if (box && !silent) box.innerHTML = '<p class="update-warn">更新信息格式不对。</p>'; return; }
  var newer = (+app.versionCode || 0) > curCode();
  LS.set('upd9', { at: Date.now(), app: newer ? app : null });
  if (box) renderUpdateBox(box, app, newer);
  if (silent && newer && current === 'Home' && $('sheetWrap').hidden && !$('q').value.trim()) renderIdle();
};
/* 内容热更新：界面和菜谱数据（网页文件）不用装包就能换。安卓端下载、校验、解压，好了回调 onWebReady。 */
function webVer() { try { return window.AndroidWeb ? +AndroidWeb.version() : 0; } catch (e) { return 0; } }
function fmtVer(v) { v = String(v); return v.length >= 12 ? v.slice(0, 4) + '-' + v.slice(4, 6) + '-' + v.slice(6, 8) + ' ' + v.slice(8, 10) + ':' + v.slice(10, 12) : v; }
function checkWeb(w) {
  if (!window.AndroidWeb || !w || !w.url || !w.sha256) return;
  if ((+w.version || 0) <= webVer() || (+w.minApp || 0) > curCode()) return;
  LS.set('webNote9', w.notes || '');
  AndroidWeb.fetch(w.url, w.sha256, String(w.version));
}
var webReady = null;
window.onWebReady = function (v) {
  webReady = v;
  if (current === 'Home' && $('sheetWrap').hidden && !$('q').value.trim()) renderIdle();
  var b = $('updateBox'); if (b) b.innerHTML = '<p>新内容已下载好。</p><button class="btn primary" data-act="webApply">刷新用上</button>';
};
window.onWebError = function (m) { var b = $('updateBox'); if (b && !updSilent) b.insertAdjacentHTML('beforeend', '<p class="update-warn">内容更新失败：' + E(m) + '</p>'); };
function webCard() {
  if (!webReady) return '';
  return '<button class="home-card update" data-act="webApply"><b>内容更新好了，点这里刷新</b><span>' + E(LS.get('webNote9', '') || '不用装安装包，收藏和清单都还在') + '</span></button>';
}
window.onAppUpdateError = function (m) {
  var silent = updSilent; updSilent = false; if (silent) return; // 自动检查失败不打扰
  var b = $('updateBox'); if (b) b.innerHTML = '<p class="update-warn">检查更新失败：' + E(m) + '。检查网络后再试。</p>';
};
window.onLauncherChanged = function (ok) { toast(ok ? '桌面图标已更换' : '更换失败'); renderSettings(); };

/* ---------- 备份 ---------- */
var BACKUP_KEYS = ['fav2', 'shop2', 'cooked2', 'customRecipes3', 'customIngredients3', 'weekPlan87', 'links9', 'customDishes9', 'recents9', 'prefs9', 'shopDone9', 'pantry9', 'tagfix9', 'vocabx9'];
function doBackup() {
  var o = { version: 9 };
  BACKUP_KEYS.forEach(function (k) { o[k] = LS.get(k, null); });
  var s = JSON.stringify(o);
  if (window.AndroidBackup) AndroidBackup.save(s);
  else { var a = document.createElement('a'); a.href = URL.createObjectURL(new Blob([s], { type: 'application/json' })); a.download = '好好吃饭备份.json'; a.click(); }
}
window.onBackupText = function (text) {
  var st = $('backupStatus');
  try {
    var b = JSON.parse(text), map = null;
    if (b.version === 9) { map = {}; BACKUP_KEYS.forEach(function (k) { if (b[k] != null) map[k] = b[k]; }); }
    else if (b.version === 3 && Array.isArray(b.fav) && Array.isArray(b.shop)) map = { fav2: b.fav, shop2: b.shop, cooked2: b.cooked || [], customRecipes3: b.customRecipes || [], customIngredients3: b.customIngredients || [] };
    if (!map) throw new Error();
    $('modalBody').innerHTML = '<h3>恢复备份</h3><p>会替换当前的收藏、链接和清单。</p><div class="btn-row"><button class="btn" data-act="modalClose">取消</button><button class="btn primary" id="rsOk">恢复</button></div>';
    showModal();
    $('rsOk').onclick = function () { Object.keys(map).forEach(function (k) { LS.set(k, map[k]); }); location.reload(); };
  } catch (e) { if (st) st.textContent = '这个文件不是好好吃饭的备份，没有改动现有数据。'; }
};

/* ---------- 事件 ---------- */
var pressTimer = null, longFired = false;
function bindPress() {
  document.addEventListener('touchstart', function (e) {
    var p = e.target.closest && e.target.closest('[data-plat]');
    longFired = false;
    if (!p) return;
    pressTimer = setTimeout(function () { longFired = true; openPlatform(p.getAttribute('data-plat'), queryOf(curDish), true); }, 550);
  }, { passive: true });
  ['touchend', 'touchmove', 'touchcancel'].forEach(function (ev) { document.addEventListener(ev, function () { clearTimeout(pressTimer); }, { passive: true }); });
  document.addEventListener('contextmenu', function (e) {
    var p = e.target.closest && e.target.closest('[data-plat]');
    if (!p) return;
    e.preventDefault();
    if (!('ontouchstart' in window)) { longFired = true; openPlatform(p.getAttribute('data-plat'), queryOf(curDish), true); }
  });
}
var ACTS = {
  settings: function () { goPage('Set'); },
  setBack: function () { goPage('Home'); },
  reroll: function () { pickCache = null; renderIdle(); },
  closeSheet: closeSheet,
  fav: function () { if (fav.has(curDish)) fav.delete(curDish); else fav.add(curDish); LS.set('fav2', Array.from(fav)); renderSheet(); },
  mod: function (el) { curMod = el.getAttribute('data-m'); LS.set('mod9', curMod); renderSheet(); },
  addLink: function () {
    var c = ''; try { if (window.AndroidNav) c = AndroidNav.clip(); } catch (e) {}
    openLinkModal(/https?:\/\//.test(c) ? c : '', curDish);
  },
  toWeek: weekModal,
  clPick: function (el) { clPick = +el.getAttribute('data-i'); clDone = {}; renderSheet(); },
  clShop: function () { var r = CL[curDish][clPick]; shop.push({ name: curDish, mult: 1, items: r.ing.map(function (i) { return [i[0], i[1] || '']; }) }); saveShop(); toast('用料已加入清单'); },
  goCunlv: function () { browse.mode = 'cunlv'; browse.pick = null; goPage('Browse'); },
  toShop: function () { var r = byR[curDish]; shop.push({ name: curDish, mult: 1, items: r.ingredients.map(function (i) { return [i[0], i[1]]; }) }); saveShop(); toast('用料已加入清单'); },
  addCustom: function () { customDishes.push(curDish); LS.set('customDishes9', customDishes); addDish(curDish, -1, -1, true); renderSheet(); toast('已加入我的菜名'); },
  delCustom: function () { customDishes = customDishes.filter(function (n) { return n !== curDish; }); LS.set('customDishes9', customDishes); ALL = ALL.filter(function (d) { return d.name !== curDish; }); delete byName[curDish]; renderSheet(); toast('已从我的菜名移除'); },
  modalClose: closeModal,
  lkSave: saveLink,
  browseMode: function (el) { browse.mode = el.getAttribute('data-m'); browse.pick = null; renderBrowse(); },
  browsePick: function (el) { browse.pick = +el.getAttribute('data-i'); renderBrowse(); },
  browseBack: function () { browse.pick = null; renderBrowse(); },
  shopAdd: function () { var i = $('shopInput'), v = i.value.trim(); if (!v) return; var g = shop.filter(function (x) { return x.name === '我加的'; })[0]; if (!g) { g = { name: '我加的', mult: 1, items: [] }; shop.unshift(g); } g.items.push([v, '']); saveShop(); renderShop(); },
  backup: doBackup,
  restore: function () { if (window.AndroidBackup) AndroidBackup.load(); else { var f = document.createElement('input'); f.type = 'file'; f.onchange = function () { var rd = new FileReader(); rd.onload = function () { window.onBackupText(rd.result); }; rd.readAsText(f.files[0]); }; f.click(); } },
  webApply: function () { if (window.AndroidWeb) AndroidWeb.apply(); },
  goUpdate: function () {
    goPage('Set'); var u = LS.get('upd9', null), box = $('updateBox');
    if (u && u.app && box) { renderUpdateBox(box, u.app, true); box.scrollIntoView(); }
  },
  checkUpdate: function () { updSilent = false; $('updateBox').textContent = '正在检查…'; if (window.AndroidUpdate) AndroidUpdate.check(FEED_URL); else fetch(FEED_URL, { cache: 'no-store' }).then(function (r) { return r.text(); }).then(window.onAppUpdateInfo).catch(function (e) { window.onAppUpdateError(e.message); }); }
};
function onClick(e) {
  var t = e.target, el;
  if ((el = t.closest('[data-plat]'))) { if (!longFired) openPlatform(el.getAttribute('data-plat'), queryOf(curDish)); longFired = false; return; }
  if ((el = t.closest('[data-pick]'))) { $('lkDish').value = el.getAttribute('data-pick'); pickRefresh(); return; }
  if ((el = t.closest('[data-link]'))) { openUrl(links[curDish][+el.getAttribute('data-link')].u); return; }
  if ((el = t.closest('[data-del]'))) {
    var i = +el.getAttribute('data-del'), gone = links[curDish].splice(i, 1)[0];
    if (!links[curDish].length) delete links[curDish];
    saveLinks(); renderSheet(); toast('已删除：' + (gone.t || gone.u).slice(0, 18));
    return;
  }
  if ((el = t.closest('[data-step]'))) { var si = +el.getAttribute('data-step'); clDone[si] = !clDone[si]; el.classList.toggle('done', !!clDone[si]); return; }
  if ((el = t.closest('[data-url]'))) { openUrl(el.getAttribute('data-url')); return; }
  if ((el = t.closest('[data-week]'))) {
    var v = el.getAttribute('data-week').split(',');
    if (window.weekAddDish && window.weekAddDish(+v[0], +v[1], curDish)) toast('已排进一周'); else toast('一周计划还没准备好');
    closeModal(); return;
  }
  if ((el = t.closest('[data-shopdel]'))) { shop.splice(+el.getAttribute('data-shopdel'), 1); saveShop(); renderShop(); return; }
  if ((el = t.closest('[data-iconkey]'))) { if (window.AndroidLauncher) AndroidLauncher.choose(el.getAttribute('data-iconkey')); return; }
  if ((el = t.closest('[data-open]'))) { openR(el.getAttribute('data-open')); return; }
  if ((el = t.closest('[data-act]'))) { var f = ACTS[el.getAttribute('data-act')]; if (f) f(el); return; }
  if (t.id === 'qClear') { $('q').value = ''; onQuery(); $('q').focus(); return; }
  if (t.id === 'modal') closeModal();
}
function onChange(e) {
  var t = e.target, id;
  if ((id = t.getAttribute('data-platset'))) {
    prefs.off = prefs.off.filter(function (x) { return x !== id; }); prefs.web = prefs.web.filter(function (x) { return x !== id; });
    if (t.value === 'off') prefs.off.push(id);
    if (t.value === 'web') prefs.web.push(id);
    LS.set('prefs9', prefs);
  }
  if ((id = t.getAttribute('data-shopitem'))) { if (t.checked) shopDone.add(id); else shopDone.delete(id); saveShop(); t.closest('.shop-item').classList.toggle('done', t.checked); }
}
window.appBack = function () {
  if (!$('modal').hidden) { closeModal(); return true; }
  if (!$('sheetWrap').hidden) { closeSheet(); return true; }
  if (current === 'Set') { goPage('Home'); return true; }
  if (current === 'Browse' && browse.pick !== null) { browse.pick = null; renderBrowse(); return true; }
  if (current === 'Home' && $('q').value) { $('q').value = ''; onQuery(); return true; }
  if (current !== 'Home') { goPage('Home'); return true; }
  return false;
};
function setAppearance() {
  try {
    var dark = window.themeDark ? themeDark() : matchMedia('(prefers-color-scheme:dark)').matches;
    if (window.AndroidBackup) AndroidBackup.appearance(getComputedStyle(document.documentElement).getPropertyValue('--bg').trim(), dark);
  } catch (e) {}
}

/* plan.js 加载前要有导航和分页 */
document.querySelector('.navin').innerHTML = NAV.map(function (n) { return '<button data-p="' + n[0] + '">' + icon(n[1]) + '<span>' + n[2] + '</span></button>'; }).join('');
document.querySelectorAll('.navin button').forEach(function (b) { b.onclick = function () { closeSheet(); goPage(b.getAttribute('data-p')); }; });
rebuildDishes();

function appInit() {
  // plan.js 把“一周”按钮加在最后，挪到清单前面
  var nav = document.querySelector('.navin'), wk = nav.querySelector('[data-p="Week"]'), sh = nav.querySelector('[data-p="Shop"]');
  if (wk && sh) { wk.innerHTML = icon('sun') + '<span>一周</span>'; nav.insertBefore(wk, sh); }
  document.querySelector('[data-act="settings"]').innerHTML = icon('gear') + '<span>设置</span>';
  document.addEventListener('click', onClick);
  document.addEventListener('change', onChange);
  bindPress();
  $('q').addEventListener('input', onQuery);
  $('q').addEventListener('keydown', function (e) { if (e.key === 'Enter') { var q = $('q').value.trim(); if (q) { openR(q); $('q').blur(); } } });
  setAppearance();
  try { matchMedia('(prefers-color-scheme:dark)').addEventListener('change', setAppearance); } catch (e) {}
  goPage('Home');
  autoCheckUpdate();
}
